# المرصد العلمي - Scientific Observatory

منصة عربية لمشاركة الأبحاث العلمية والنقاش بين الباحثين، مبنية بـ Flask + SQLite.

## الميزات

- تسجيل دخول حقيقي بحساب Google (OAuth 2.0) + حسابات تجريبية للاختبار
- نظام أدوار (عضو / مشرف / مالك) برموز سرية
- لوحة إعدادات: الوضع الداكن/الفاتح + لغة عربية/إنجليزية
- رفع صورة شخصية للملف الشخصي
- **محرر Markdown** للأبحاث والتعليقات مع شريط أدوات ومعاينة لحظية
- موافقة المشرفين على أبحاث الأعضاء قبل النشر
- تعليقات على الأبحاث مع دعم Markdown
- نظام نقاط ورُتب: مبتدئ → باحث → خبير → عالم
- إهداء نقاط للأعضاء من المالك (موجبة/سالبة) مع سجل
- منع تكرار أسماء المستخدمين
- إشعارات داخلية للأحداث المهمة

## التثبيت

```bash
# 1. ثبّت المكتبات
pip install -r requirements.txt

# 2. أعدّ ملف البيئة
cp .env.example .env
nano .env

# 3. شغّل التطبيق
python app.py
```

افتح في المتصفح: http://localhost:5000

## محرر Markdown

عند كتابة بحث أو تعليق، تستطيع استخدام صياغة Markdown:

```markdown
# عنوان رئيسي
## عنوان فرعي

**نص عريض** و *نص مائل* و ~~مشطوب~~

- قائمة نقطية
- نقطة ثانية

1. قائمة مرقمة
2. ثانياً

> اقتباس

`كود سطر واحد`

\`\`\`python
كود متعدد الأسطر
\`\`\`

[رابط](https://example.com)

| جدول | كذلك |
|------|------|
| مدعوم | نعم |
```

شريط الأدوات في صفحة "نشر بحث" يساعدك على الإدراج السريع، وزر "معاينة" يعرض كيف سيظهر النص للقراء.

> **ملاحظة أمان**: HTML الخام محجوب تلقائياً، لذا `<script>` أو أي وسم آخر يُعرض كنص عادي ولا يُنفَّذ.

## ملف `.env`

```ini
SECRET_KEY=long-random-string

# Google OAuth
GOOGLE_CLIENT_ID=your-client-id.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=your-client-secret

# الرموز السرية للأدوار
MEMBER_CODE=member-2024
ADMIN_CODE=admin-2024
OWNER_CODE=owner-2024
```

### إعداد Google OAuth

1. اذهب إلى https://console.cloud.google.com
2. أنشئ مشروعاً جديداً
3. APIs & Services ← Credentials ← Create Credentials ← OAuth client ID
4. Application type: **Web application**
5. Authorized redirect URI: `http://localhost:5000/auth/google/callback`
6. انسخ Client ID و Client Secret إلى `.env`

> إذا لم تُعدّ Google OAuth، يعمل التطبيق بالحسابات التجريبية فقط.

## الحسابات التجريبية

| البريد              | الدور المقترح |
|---------------------|---------------|
| owner@marsad.com    | مالك          |
| admin@marsad.com    | مشرف          |
| ahmad@marsad.com    | عضو           |
| sara@marsad.com     | عضو           |

بعد اختيار حساب تجريبي، تُطلب منك رموز الأدوار من `.env`.

## كيف يعمل اختيار الدور؟

بعد أول تسجيل دخول، يُوجَّه المستخدم إلى `/select-role`:
1. يختار: **عضو** أو **مشرف** أو **مالك**
2. يدخل الرمز السري المقابل من `.env`
3. إن طابق الرمز، تُحفظ صلاحياته ويُوجَّه للرئيسية

## نظام الأبحاث

- **العضو** ينشر بحثاً ← يصبح حالته `pending` (بانتظار المراجعة)
- **المشرف/المالك** يراه في `/admin/pending` ويوافق أو يرفض (مع سبب)
- عند الموافقة: يصبح `approved`، يظهر للجميع، صاحبه يحصل على +1 نقطة
- عند الرفض: يصبح `rejected`، يظهر لصاحبه فقط مع سبب الرفض
- **المشرف/المالك** ينشرون مباشرة (تخطي المراجعة)

## نظام النقاط والرتب

| النقاط | الرتبة | اللون |
|--------|--------|-------|
| 120+   | عالم   | ذهبي |
| 70-119 | خبير   | سماوي |
| 20-69  | باحث   | بنفسجي |
| 0-19   | مبتدئ  | أخضر فاتح |

النقاط تُكتسب بنشر أبحاث معتمدة (+1 لكل بحث).
المالك يستطيع إهداء نقاط مخصصة (موجبة أو سالبة) لأي عضو.

## هيكل المشروع

```
marsad/
├── app.py                      # التطبيق الرئيسي (1000+ سطر)
├── requirements.txt
├── .env.example
├── marsad.db                   # SQLite (تُنشأ تلقائياً)
├── static/
│   ├── img/default_avatar.png
│   └── uploads/avatars/
└── templates/
    ├── base.html               # القالب الأساسي (theme + lang)
    ├── landing.html
    ├── login.html
    ├── select_role.html
    ├── settings.html
    ├── home.html
    ├── profile.html
    ├── edit_profile.html
    ├── research.html
    ├── new_research.html       # محرر Markdown مع معاينة
    ├── view_research.html      # عرض Markdown + تعليقات
    ├── pending_research.html   # مراجعة (مشرف)
    ├── give_points.html        # إهداء نقاط (مالك)
    └── notifications.html
```

## نقاط للنشر في الإنتاج

- استبدل `SECRET_KEY` بقيمة طويلة عشوائية
- شغّل خلف WSGI (Gunicorn) خلف Nginx
- استبدل SQLite بـ PostgreSQL للأحمال الحقيقية
- استخدم HTTPS وحدّث redirect URI في Google Console
- أضف rate limiting و CSRF protection

## الترخيص

استخدام شخصي/تعليمي.
