"""
المرصد العلمي - التطبيق الرئيسي (نسخة موسّعة)
Scientific Observatory - Extended Main Application

الميزات الجديدة:
- تسجيل دخول Google OAuth حقيقي
- نظام أدوار (عضو/مشرف/مالك) برموز سرية
- لوحة إعدادات (وضع داكن/فاتح + لغة)
- رفع صور شخصية وصور/ملفات في الدردشة
- تعليقات على الأبحاث
- موافقة المشرفين على الأبحاث قبل النشر
- هدية نقاط من المالك عبر username
- أوامر داخل الكروب (تثبيت/حذف) + سجل المحذوفات
- نظام تحذيرات (مرتين ثم طرد)
"""

import os
import sqlite3
import secrets
import re
from datetime import datetime
from functools import wraps

from flask import (
    Flask, render_template, redirect, url_for, session,
    request, jsonify, flash, send_from_directory, abort, g
)
from werkzeug.utils import secure_filename
from dotenv import load_dotenv
from markupsafe import Markup
import mistune

load_dotenv()

# Markdown renderer - escape=True يمنع HTML خام (لا <script>)
# hard_wrap=True يحوّل سطر جديد إلى <br> (أكثر طبيعية للمستخدمين)
_md = mistune.create_markdown(escape=True, hard_wrap=True,
                              plugins=['strikethrough', 'table', 'url', 'task_lists'])

def render_md(text):
    """يحوّل نص Markdown إلى HTML آمن."""
    if not text:
        return Markup('')
    return Markup(_md(text))


# ════ كلمات المرور (PBKDF2-SHA256) ════
import hashlib

def hash_password(password):
    """ينتج hash آمن من PBKDF2 مع salt عشوائي. النتيجة: '$pbkdf2$<iter>$<salt>$<hash>' """
    if not password:
        return None
    salt = secrets.token_hex(16)
    iterations = 200000
    dk = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'),
                              salt.encode('utf-8'), iterations)
    return f'$pbkdf2$${iterations}$${salt}$${dk.hex()}'

def verify_password(password, stored_hash):
    """يتحقق من تطابق كلمة المرور مع الـhash المخزن."""
    if not stored_hash or not password:
        return False
    try:
        parts = stored_hash.split('$$')
        if len(parts) != 4 or not parts[0].endswith('pbkdf2'):
            return False
        iterations = int(parts[1])
        salt = parts[2]
        expected = parts[3]
        dk = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'),
                                  salt.encode('utf-8'), iterations)
        return secrets.compare_digest(dk.hex(), expected)
    except Exception:
        return False


def reading_time(text, lang='ar'):
    """يحسب وقت القراءة المتوقع. 200 كلمة عربية ≈ 1 دقيقة."""
    if not text:
        return None
    # عدّ الكلمات (يفصل بأي whitespace)
    words = len(text.split())
    minutes = max(1, round(words / 200))
    if lang == 'ar':
        if minutes == 1:
            return 'دقيقة قراءة'
        elif minutes == 2:
            return 'دقيقتان قراءة'
        elif minutes <= 10:
            return f'{minutes} دقائق قراءة'
        else:
            return f'{minutes} دقيقة قراءة'
    else:
        return f'{minutes} min read'


# ══════════════════════════════════════
# إعدادات التطبيق
# ══════════════════════════════════════
app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'marsad_dev_secret_change_me')

# ════ إعدادات أمان الجلسة ════
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,      # JavaScript لا يستطيع قراءة الكوكي
    SESSION_COOKIE_SAMESITE='Lax',     # حماية CSRF عبر cross-site
    SESSION_COOKIE_SECURE=False,       # ضع True عند النشر بـHTTPS فقط
    PERMANENT_SESSION_LIFETIME=60*60*24*7,  # الجلسة تنتهي بعد 7 أيام
)

UPLOAD_ROOT = os.path.join(app.root_path, 'static', 'uploads')
AVATAR_DIR   = os.path.join(UPLOAD_ROOT, 'avatars')
NEWS_DIR     = os.path.join(UPLOAD_ROOT, 'news')
RESEARCH_DIR = os.path.join(UPLOAD_ROOT, 'research')
BOOKS_DIR    = os.path.join(UPLOAD_ROOT, 'books')
ASTRO_DIR    = os.path.join(UPLOAD_ROOT, 'astro')
AUDIO_DIR    = os.path.join(UPLOAD_ROOT, 'audio')
for d in (AVATAR_DIR, NEWS_DIR, RESEARCH_DIR, BOOKS_DIR, ASTRO_DIR, AUDIO_DIR):
    os.makedirs(d, exist_ok=True)

ALLOWED_IMG  = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
ALLOWED_PDF  = {'pdf'}
MAX_UPLOAD_MB = 8
MAX_BOOK_MB   = 50   # PDF كتاب: حتى 50MB
MAX_ASTRO_MB  = 200  # صور فلكية: حتى 200MB (بدون حد عملي يُسمى "ضخم")
# نضع MAX_CONTENT_LENGTH عند أعلى حد مسموح من بين كل المسارات
app.config['MAX_CONTENT_LENGTH'] = MAX_ASTRO_MB * 1024 * 1024

# رموز الأدوار: قيم افتراضية من .env، لكن يمكن تعديل رمز المالك من DB
ROLE_CODES_DEFAULTS = {
    'member': os.getenv('MEMBER_CODE', 'member-2024'),
    'admin':  os.getenv('ADMIN_CODE',  'admin-2024'),
    'owner':  os.getenv('OWNER_CODE',  'owner-2024'),
}

def get_role_code(role):
    """يقرأ رمز الدور من DB (إن كان مخزناً) وإلا من القيمة الافتراضية."""
    if role not in ROLE_CODES_DEFAULTS:
        return ''
    try:
        db = sqlite3.connect(DB)
        db.row_factory = sqlite3.Row
        row = db.execute("SELECT value FROM app_settings WHERE key=?",
                         (f'role_code_{role}',)).fetchone()
        db.close()
        if row:
            return row['value']
    except Exception:
        pass
    return ROLE_CODES_DEFAULTS[role]

def set_role_code(role, new_code, by_user_id=None):
    """يحفظ رمز دور جديد في DB."""
    if role not in ROLE_CODES_DEFAULTS:
        return False
    db = sqlite3.connect(DB)
    db.execute("""INSERT INTO app_settings(key, value, updated_by, updated_at)
                  VALUES(?, ?, ?, CURRENT_TIMESTAMP)
                  ON CONFLICT(key) DO UPDATE
                    SET value=excluded.value,
                        updated_by=excluded.updated_by,
                        updated_at=CURRENT_TIMESTAMP""",
               (f'role_code_{role}', new_code, by_user_id))
    db.commit()
    db.close()
    return True

# للتوافق مع الكود القديم: dict-like wrapper
class _RoleCodesProxy:
    def __getitem__(self, role):
        return get_role_code(role)
    def get(self, role, default=''):
        return get_role_code(role) or default

ROLE_CODES = _RoleCodesProxy()

# Google OAuth
GOOGLE_CLIENT_ID     = os.getenv('GOOGLE_CLIENT_ID', '')
GOOGLE_CLIENT_SECRET = os.getenv('GOOGLE_CLIENT_SECRET', '')
GOOGLE_ENABLED = bool(GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET
                      and 'your-google' not in GOOGLE_CLIENT_ID)

oauth = None
if GOOGLE_ENABLED:
    from authlib.integrations.flask_client import OAuth
    oauth = OAuth(app)
    oauth.register(
        name='google',
        client_id=GOOGLE_CLIENT_ID,
        client_secret=GOOGLE_CLIENT_SECRET,
        server_metadata_url='https://accounts.google.com/.well-known/openid-configuration',
        client_kwargs={'scope': 'openid email profile'},
    )

DB = 'marsad.db'

# ══════════════════════════════════════
# CSRF Token (حماية ضد التزوير)
# ══════════════════════════════════════
def csrf_token():
    """يولّد ويعيد CSRF token للجلسة الحالية."""
    if '_csrf' not in session:
        session['_csrf'] = secrets.token_hex(32)
    return session['_csrf']

@app.before_request
def csrf_protect():
    """يتحقق من الـCSRF token في كل POST، عدا OAuth callback و APIs محددة."""
    if request.method not in ('POST', 'PUT', 'DELETE', 'PATCH'):
        return
    # استثناءات: OAuth و demo login و auth endpoints (تستخدم نموذج جلسة بسيط)
    safe_paths = ('/auth/google/callback', '/auth/google/demo',
                  '/auth/login', '/auth/register')
    if request.path in safe_paths:
        return
    # تحقق
    sent = request.form.get('_csrf') or request.headers.get('X-CSRF-Token','')
    expected = session.get('_csrf','')
    if not expected or sent != expected:
        # AJAX؟ أعد JSON
        if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'error':'csrf_failed'}), 403
        abort(403)


@app.after_request
def add_security_headers(response):
    """يضيف headers أمنية لكل استجابة."""
    # X-Content-Type-Options: يمنع المتصفح من تخمين MIME type (anti-MIME-sniffing)
    response.headers['X-Content-Type-Options'] = 'nosniff'
    # X-Frame-Options: يمنع تضمين الموقع في iframe (clickjacking)
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    # Referrer-Policy: يقلل تسريب المعلومات للمواقع الأخرى
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    # X-XSS-Protection (للمتصفحات القديمة)
    response.headers['X-XSS-Protection'] = '1; mode=block'
    # Permissions-Policy: يقفل APIs حساسة لا نحتاجها
    response.headers['Permissions-Policy'] = 'geolocation=(), microphone=(), camera=()'
    return response

# ══════════════════════════════════════
# Rate Limiter بسيط في الذاكرة (لحماية login/comment/follow)
# ══════════════════════════════════════
import time as _time
from collections import defaultdict, deque
_rate_buckets = defaultdict(deque)  # key -> deque of timestamps

def rate_limit(key, max_hits, window_sec):
    """يعيد True إذا تجاوز المستخدم الحد. key مثل 'comment:user_5'."""
    now = _time.time()
    bucket = _rate_buckets[key]
    # امسح القديم
    while bucket and bucket[0] < now - window_sec:
        bucket.popleft()
    if len(bucket) >= max_hits:
        return True
    bucket.append(now)
    return False


# ══════════════════════════════════════
# نظام حماية تسجيل الدخول المتدرّج
# ══════════════════════════════════════
# تخزن: {key: {'fails': int, 'locked_until': float|None, 'penalty_level': int}}
_login_attempts = {}

# سُلّم العقوبات (بالثواني). المفتاح: عند الوصول لهذا العدد من المحاولات الفاشلة
LOGIN_PENALTIES = [
    (4,   60),       # المحاولة الفاشلة #4 (بعد 3 خاطئة) → دقيقة
    (5,   5*60),     # #5 (محاولة واحدة خاطئة بعد العقوبة الأولى) → 5 دقائق
    (6,   30*60),    # #6 (محاولتين بعد العقوبة الأولى) → 30 دقيقة
    (8,   60*60),    # #8 → ساعة
    (12,  3*60*60),  # #12 → 3 ساعات (حماية إضافية)
]
# بعد هذه المدة من النجاح أو من انتهاء آخر عقوبة، نعيد العداد لصفر
LOGIN_RESET_AFTER = 30 * 60   # 30 دقيقة من الهدوء = إعادة العداد

def login_check_lockout(key):
    """يتفقد إن المفتاح مقفل حالياً.
       يعيد: (locked, seconds_remaining, fails_count) """
    now = _time.time()
    info = _login_attempts.get(key)
    if not info:
        return False, 0, 0

    locked_until = info.get('locked_until')
    if locked_until and now < locked_until:
        return True, int(locked_until - now), info.get('fails', 0)

    # إعادة العداد بعد فترة طويلة من الهدوء
    last_fail = info.get('last_fail', 0)
    if last_fail and now - last_fail > LOGIN_RESET_AFTER:
        _login_attempts.pop(key, None)
        return False, 0, 0

    return False, 0, info.get('fails', 0)

def login_record_fail(key):
    """يسجل محاولة فاشلة ويُطبّق العقوبة المناسبة.
       يعيد: (penalty_seconds, fails_total) """
    now = _time.time()
    info = _login_attempts.get(key, {'fails': 0, 'locked_until': None, 'last_fail': 0})
    info['fails'] = info.get('fails', 0) + 1
    info['last_fail'] = now

    # ابحث عن العقوبة المناسبة
    penalty = 0
    for threshold, seconds in LOGIN_PENALTIES:
        if info['fails'] >= threshold:
            penalty = seconds  # نأخذ آخر عقوبة مطبقة

    if penalty > 0:
        info['locked_until'] = now + penalty
    else:
        info['locked_until'] = None

    _login_attempts[key] = info
    return penalty, info['fails']

def login_record_success(key):
    """امسح سجل المحاولات عند تسجيل دخول ناجح."""
    _login_attempts.pop(key, None)

def format_duration_ar(seconds):
    """يحول الثواني لنص عربي قابل للقراءة."""
    if seconds < 60:
        return f'{seconds} ثانية'
    minutes = seconds // 60
    if minutes < 60:
        if minutes == 1:
            return 'دقيقة'
        elif minutes == 2:
            return 'دقيقتين'
        elif minutes <= 10:
            return f'{minutes} دقائق'
        else:
            return f'{minutes} دقيقة'
    hours = minutes // 60
    if hours == 1:
        return 'ساعة'
    elif hours == 2:
        return 'ساعتين'
    elif hours <= 10:
        return f'{hours} ساعات'
    else:
        return f'{hours} ساعة'


# ══════════════════════════════════════
# الترجمة (نصوص ar/en)
# ══════════════════════════════════════
TRANSLATIONS = {
    'ar': {
        'home':'الرئيسية','research':'الأبحاث','news':'الأخبار',
        'notifications':'الإشعارات','profile':'ملفي','settings':'الإعدادات',
        'logout':'تسجيل الخروج','login':'تسجيل الدخول',
        'dark_mode':'الوضع الداكن','light_mode':'الوضع الفاتح',
        'language':'اللغة','arabic':'العربية','english':'الإنجليزية',
        'save':'حفظ','cancel':'إلغاء','delete':'حذف','edit':'تعديل',
        'pending':'بانتظار الموافقة','approve':'موافقة','reject':'رفض',
        'comments':'التعليقات','add_comment':'إضافة تعليق',
        'give_points':'إهداء نقاط',
        'pending_research':'الأبحاث المعلّقة',
        'new_research':'بحث جديد','new_news':'خبر جديد','publish':'نشر',
        'cover_image':'صورة الغلاف','select_image':'اختر صورة',
        'select_role':'اختر دورك','enter_code':'أدخل الرمز السري',
        'member':'عضو','admin':'مشرف','owner':'مالك',
        'invalid_code':'الرمز غير صحيح','welcome':'مرحباً',
        'bookmarks':'الأبحاث المفضلة','follow':'متابعة','unfollow':'إلغاء المتابعة',
        'followers':'المتابِعون','following':'يتابع','researchers':'الباحثين',
        'my_research':'أبحاثي','statistics':'الإحصائيات','reply':'رد',
        'discover':'استكشف','my_feed':'متابعاتي','download_pdf':'تنزيل PDF',
    },
    'en': {
        'home':'Home','research':'Research','news':'News',
        'notifications':'Notifications','profile':'Profile','settings':'Settings',
        'logout':'Logout','login':'Login',
        'dark_mode':'Dark Mode','light_mode':'Light Mode',
        'language':'Language','arabic':'Arabic','english':'English',
        'save':'Save','cancel':'Cancel','delete':'Delete','edit':'Edit',
        'pending':'Pending Approval','approve':'Approve','reject':'Reject',
        'comments':'Comments','add_comment':'Add Comment',
        'give_points':'Give Points',
        'pending_research':'Pending Research',
        'new_research':'New Research','new_news':'New News','publish':'Publish',
        'cover_image':'Cover Image','select_image':'Select Image',
        'select_role':'Select Your Role','enter_code':'Enter Secret Code',
        'member':'Member','admin':'Admin','owner':'Owner',
        'invalid_code':'Invalid code','welcome':'Welcome',
        'bookmarks':'Saved Research','follow':'Follow','unfollow':'Unfollow',
        'followers':'Followers','following':'Following','researchers':'Researchers',
        'my_research':'My Research','statistics':'Statistics','reply':'Reply',
        'discover':'Discover','my_feed':'Following Feed','download_pdf':'Download PDF',
    }
}

# ══════════════════════════════════════
# قاعدة البيانات
# ══════════════════════════════════════
def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_db(); c = conn.cursor()

    c.execute('''CREATE TABLE IF NOT EXISTS users (
        id            INTEGER PRIMARY KEY AUTOINCREMENT,
        google_id     TEXT UNIQUE,
        email         TEXT UNIQUE,
        password_hash TEXT DEFAULT NULL,
        name          TEXT NOT NULL,
        username      TEXT UNIQUE,
        avatar        TEXT DEFAULT '/static/img/default_avatar.png',
        cover_image   TEXT DEFAULT '',
        bio           TEXT DEFAULT '',
        points        INTEGER DEFAULT 0,
        role          TEXT DEFAULT 'member',
        role_chosen   INTEGER DEFAULT 0,
        theme         TEXT DEFAULT 'dark',
        lang          TEXT DEFAULT 'ar',
        warnings      INTEGER DEFAULT 0,
        is_banned     INTEGER DEFAULT 0,
        created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS categories (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        slug        TEXT UNIQUE NOT NULL,
        name_ar     TEXT NOT NULL,
        name_en     TEXT NOT NULL,
        icon        TEXT DEFAULT 'fa-book',
        color       TEXT DEFAULT '#7b68ee',
        sort_order  INTEGER DEFAULT 0,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS research (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id     INTEGER NOT NULL,
        category_id INTEGER DEFAULT NULL,
        title       TEXT NOT NULL,
        summary     TEXT NOT NULL,
        content     TEXT NOT NULL,
        tags        TEXT DEFAULT '',
        cover_image TEXT DEFAULT '',
        views       INTEGER DEFAULT 0,
        likes       INTEGER DEFAULT 0,
        is_featured INTEGER DEFAULT 0,
        status      TEXT DEFAULT 'pending',
        reviewed_by INTEGER DEFAULT NULL,
        reviewed_at DATETIME DEFAULT NULL,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id),
        FOREIGN KEY(category_id) REFERENCES categories(id)
    )''')

    # معرض صور الأبحاث (متعدد)
    c.execute('''CREATE TABLE IF NOT EXISTS research_images (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        research_id INTEGER NOT NULL,
        image       TEXT NOT NULL,
        caption     TEXT DEFAULT '',
        sort_order  INTEGER DEFAULT 0,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(research_id) REFERENCES research(id) ON DELETE CASCADE
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS comments (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        research_id INTEGER NOT NULL,
        user_id     INTEGER NOT NULL,
        parent_id   INTEGER DEFAULT NULL,
        content     TEXT NOT NULL,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(research_id) REFERENCES research(id),
        FOREIGN KEY(user_id) REFERENCES users(id),
        FOREIGN KEY(parent_id) REFERENCES comments(id) ON DELETE CASCADE
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS news (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id     INTEGER NOT NULL,
        title       TEXT NOT NULL,
        content     TEXT NOT NULL,
        image       TEXT DEFAULT '',
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS notifications (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id     INTEGER NOT NULL,
        message     TEXT NOT NULL,
        link        TEXT DEFAULT '',
        is_read     INTEGER DEFAULT 0,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )''')

    # حذف جداول الكروبات إن وُجدت من نسخة سابقة
    for tbl in ('group_messages','group_members','groups'):
        try: c.execute(f"DROP TABLE IF EXISTS {tbl}")
        except: pass

    c.execute('''CREATE TABLE IF NOT EXISTS likes (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id     INTEGER NOT NULL,
        research_id INTEGER NOT NULL,
        UNIQUE(user_id, research_id),
        FOREIGN KEY(user_id) REFERENCES users(id),
        FOREIGN KEY(research_id) REFERENCES research(id)
    )''')

    # الأبحاث المفضلة (bookmarks)
    c.execute('''CREATE TABLE IF NOT EXISTS bookmarks (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id     INTEGER NOT NULL,
        research_id INTEGER NOT NULL,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, research_id),
        FOREIGN KEY(user_id) REFERENCES users(id),
        FOREIGN KEY(research_id) REFERENCES research(id) ON DELETE CASCADE
    )''')

    # متابعة الباحثين
    c.execute('''CREATE TABLE IF NOT EXISTS follows (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        follower_id  INTEGER NOT NULL,
        followed_id  INTEGER NOT NULL,
        created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(follower_id, followed_id),
        FOREIGN KEY(follower_id) REFERENCES users(id),
        FOREIGN KEY(followed_id) REFERENCES users(id)
    )''')

    # ردود التعليقات (parent_id لشجرة التعليقات)
    # ملاحظة: نستخدم نفس جدول comments مع عمود parent_id جديد (يُضاف في upgrade_schema)

    c.execute("DROP TABLE IF EXISTS warnings_log")

    c.execute('''CREATE TABLE IF NOT EXISTS points_gifts (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        from_user   INTEGER NOT NULL,
        to_user     INTEGER NOT NULL,
        points      INTEGER NOT NULL,
        reason      TEXT DEFAULT '',
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
    )''')

    # ════ المكتبة ════
    c.execute('''CREATE TABLE IF NOT EXISTS book_categories (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        slug       TEXT UNIQUE NOT NULL,
        name_ar    TEXT NOT NULL,
        name_en    TEXT NOT NULL,
        icon       TEXT DEFAULT 'fa-book',
        color      TEXT DEFAULT '#7b68ee',
        sort_order INTEGER DEFAULT 0
    )''')

    c.execute('''CREATE TABLE IF NOT EXISTS books (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id      INTEGER NOT NULL,
        category_id  INTEGER,
        title        TEXT NOT NULL,
        description  TEXT DEFAULT '',
        author_name  TEXT DEFAULT '',
        cover_image  TEXT DEFAULT '',
        pdf_file     TEXT NOT NULL,
        file_size    INTEGER DEFAULT 0,
        downloads    INTEGER DEFAULT 0,
        created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id),
        FOREIGN KEY(category_id) REFERENCES book_categories(id)
    )''')

    # ════ الصور الفلكية ════
    c.execute('''CREATE TABLE IF NOT EXISTS astro_images (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id     INTEGER NOT NULL,
        title       TEXT NOT NULL,
        description TEXT DEFAULT '',
        image       TEXT NOT NULL,
        file_size   INTEGER DEFAULT 0,
        views       INTEGER DEFAULT 0,
        likes       INTEGER DEFAULT 0,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )''')

    # ════ الرسائل العامة (broadcasts) ════
    c.execute('''CREATE TABLE IF NOT EXISTS broadcasts (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        sender_id   INTEGER NOT NULL,
        title       TEXT NOT NULL,
        content     TEXT NOT NULL,
        recipients  INTEGER DEFAULT 0,
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(sender_id) REFERENCES users(id)
    )''')

    # ════ سجل أمني للأحداث الحساسة ════
    c.execute('''CREATE TABLE IF NOT EXISTS security_log (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id     INTEGER,
        action      TEXT NOT NULL,
        ip          TEXT,
        details     TEXT DEFAULT '',
        created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(user_id) REFERENCES users(id)
    )''')

    # ════ إعدادات قابلة للتعديل (رموز الأدوار، إلخ) ════
    c.execute('''CREATE TABLE IF NOT EXISTS app_settings (
        key         TEXT PRIMARY KEY,
        value       TEXT NOT NULL,
        updated_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_by  INTEGER,
        FOREIGN KEY(updated_by) REFERENCES users(id)
    )''')

    conn.commit()
    upgrade_schema(c)
    conn.commit()

    # بذور الأقسام الافتراضية (تُضاف فقط إن الجدول فارغ)
    c.execute("SELECT COUNT(*) FROM categories")
    if c.fetchone()[0] == 0:
        default_cats = [
            ('physics',     'الفيزياء',   'Physics',     'fa-atom',          '#7b68ee', 1),
            ('astronomy',   'الفلك',      'Astronomy',   'fa-meteor',        '#d4af37', 2),
            ('chemistry',   'الكيمياء',   'Chemistry',   'fa-flask',         '#ff6b9d', 3),
            ('mathematics', 'الرياضيات',  'Mathematics', 'fa-square-root-variable', '#4ade80', 4),
            ('philosophy',  'الفلسفة',    'Philosophy',  'fa-brain',         '#fb923c', 5),
            ('engineering', 'الهندسة',    'Engineering', 'fa-gears',         '#60a5fa', 6),
        ]
        c.executemany("""INSERT INTO categories(slug,name_ar,name_en,icon,color,sort_order)
                         VALUES(?,?,?,?,?,?)""", default_cats)
        conn.commit()

    # بذور أقسام المكتبة
    c.execute("SELECT COUNT(*) FROM book_categories")
    if c.fetchone()[0] == 0:
        default_book_cats = [
            ('physics',     'الفيزياء',   'Physics',     'fa-atom',          '#7b68ee', 1),
            ('astronomy',   'الفلك',      'Astronomy',   'fa-meteor',        '#d4af37', 2),
            ('chemistry',   'الكيمياء',   'Chemistry',   'fa-flask',         '#ff6b9d', 3),
            ('mathematics', 'الرياضيات',  'Mathematics', 'fa-square-root-variable', '#4ade80', 4),
            ('philosophy',  'الفلسفة',    'Philosophy',  'fa-brain',         '#fb923c', 5),
            ('engineering', 'الهندسة',    'Engineering', 'fa-gears',         '#60a5fa', 6),
            ('biology',     'الأحياء',    'Biology',     'fa-dna',           '#22d3ee', 7),
            ('general',     'عام',        'General',     'fa-book',          '#a78bfa', 8),
        ]
        c.executemany("""INSERT INTO book_categories(slug,name_ar,name_en,icon,color,sort_order)
                         VALUES(?,?,?,?,?,?)""", default_book_cats)
        conn.commit()

    c.execute("SELECT COUNT(*) FROM users")
    if c.fetchone()[0] == 0:
        seed_data(c)
        conn.commit()

    conn.close()


def upgrade_schema(c):
    """ترقية قاعدة بيانات قديمة لإضافة الأعمدة الجديدة بدون فقدان البيانات."""
    def cols(table):
        try: return [r[1] for r in c.execute(f"PRAGMA table_info({table})")]
        except: return []

    for table, additions in {
        'users': [
            ('role_chosen', "ALTER TABLE users ADD COLUMN role_chosen INTEGER DEFAULT 0"),
            ('theme',       "ALTER TABLE users ADD COLUMN theme TEXT DEFAULT 'dark'"),
            ('lang',        "ALTER TABLE users ADD COLUMN lang TEXT DEFAULT 'ar'"),
            ('is_banned',   "ALTER TABLE users ADD COLUMN is_banned INTEGER DEFAULT 0"),
            ('cover_image', "ALTER TABLE users ADD COLUMN cover_image TEXT DEFAULT ''"),
            ('password_hash', "ALTER TABLE users ADD COLUMN password_hash TEXT DEFAULT NULL"),
        ],
        'research': [
            ('status',      "ALTER TABLE research ADD COLUMN status TEXT DEFAULT 'approved'"),
            ('reviewed_by', "ALTER TABLE research ADD COLUMN reviewed_by INTEGER DEFAULT NULL"),
            ('reviewed_at', "ALTER TABLE research ADD COLUMN reviewed_at DATETIME DEFAULT NULL"),
            ('cover_image', "ALTER TABLE research ADD COLUMN cover_image TEXT DEFAULT ''"),
            ('category_id', "ALTER TABLE research ADD COLUMN category_id INTEGER DEFAULT NULL"),
            ('pdf_file',    "ALTER TABLE research ADD COLUMN pdf_file TEXT DEFAULT ''"),
            ('audio_file',  "ALTER TABLE research ADD COLUMN audio_file TEXT DEFAULT ''"),
            ('audio_voice', "ALTER TABLE research ADD COLUMN audio_voice TEXT DEFAULT ''"),
            ('audio_status', "ALTER TABLE research ADD COLUMN audio_status TEXT DEFAULT 'none'"),
        ],
        'comments': [
            ('parent_id', "ALTER TABLE comments ADD COLUMN parent_id INTEGER DEFAULT NULL"),
        ],
    }.items():
        existing = cols(table)
        for col, ddl in additions:
            if col not in existing:
                try: c.execute(ddl)
                except: pass


def seed_data(c):
    users = [
        (None, 'owner@marsad.com',  'مالك المرصد',   'owner_user', '/static/img/default_avatar.png', 'مؤسس المرصد العلمي',     500, 'owner', 1),
        (None, 'admin@marsad.com',  'المشرف العام',  'admin_user', '/static/img/default_avatar.png', 'مشرف المنصة',             250, 'admin', 1),
        (None, 'ahmad@marsad.com',  'أحمد الفلكي',   'ahmad_ast',  '/static/img/default_avatar.png', 'باحث في علم الفلك',        80, 'member',1),
        (None, 'sara@marsad.com',   'سارة العلوم',   'sara_sci',   '/static/img/default_avatar.png', 'متخصصة في الفيزياء الفلكية',45, 'member',1),
        (None, 'khalid@marsad.com', 'خالد النجوم',   'khalid_st',  '/static/img/default_avatar.png', 'مهتم بالثقوب السوداء',     15, 'member',1),
    ]
    c.executemany("""INSERT INTO users(google_id,email,name,username,avatar,bio,points,role,role_chosen)
                     VALUES(?,?,?,?,?,?,?,?,?)""", users)

    research_list = [
        (1, 2, 'اكتشاف ثقب أسود جديد في مجرة درب التبانة',
         'اكتشف فريق من العلماء ثقباً أسود ضخماً في منطقة لم تُدرس من قبل.',
         'محتوى البحث التفصيلي حول الثقب الأسود وأبعاده وتأثيره على المنطقة المحيطة...',
         'فلك,ثقوب سوداء', 240, 18, 1, 'approved'),
        (3, 1, 'دراسة حول الموجات الثقالية وتأثيرها على الزمكان',
         'بحث معمق في آليات الموجات الثقالية الصادرة عن اندماج النجوم النيوترونية.',
         'محتوى البحث التفصيلي حول الموجات الثقالية...',
         'فيزياء,موجات ثقالية', 185, 12, 1, 'approved'),
        (4, 2, 'رصد كوكب خارج المجموعة الشمسية بخصائص مشابهة للأرض',
         'تم رصد كوكب على بعد 40 سنة ضوئية يمتلك غلافاً جوياً وماءً سائلاً.',
         'محتوى البحث التفصيلي حول الكوكب المكتشف...',
         'كواكب,حياة خارج الأرض', 320, 28, 1, 'approved'),
    ]
    c.executemany("""INSERT INTO research(user_id,category_id,title,summary,content,tags,views,likes,is_featured,status)
                     VALUES(?,?,?,?,?,?,?,?,?,?)""", research_list)

    news_list = [
        (1,'مركبة فضائية جديدة تنطلق نحو المريخ',
         'أعلنت وكالة ناسا اليوم عن إطلاق مركبة فضائية متطورة تحمل معداتٍ علمية متقدمة...',''),
        (1,'اكتشاف مجرة قزمة غير مرئية بالعين المجردة',
         'رصد علماء الفلك مجرةً قزمة جديدة تدور حول مجرة درب التبانة...',''),
    ]
    c.executemany("INSERT INTO news(user_id,title,content,image) VALUES(?,?,?,?)", news_list)


# ══════════════════════════════════════
# دوال مساعدة
# ══════════════════════════════════════
def get_rank(points):
    if points >= 120:
        return {'name': 'عالم', 'name_en':'Scholar', 'icon':'★★★', 'color': '#FFD700', 'next': None, 'needed': 0}
    elif points >= 70:
        return {'name': 'خبير', 'name_en':'Expert',  'icon':'★★',  'color': '#00CED1', 'next': 'عالم', 'needed': 120 - points}
    elif points >= 20:
        return {'name': 'باحث', 'name_en':'Researcher','icon':'★',   'color': '#7B68EE', 'next': 'خبير', 'needed': 70 - points}
    else:
        return {'name': 'مبتدئ','name_en':'Beginner', 'icon':'·',   'color': '#90EE90', 'next': 'باحث', 'needed': 20 - points}


def current_user():
    if 'user_id' not in session:
        return None
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE id=?", (session['user_id'],)).fetchone()
    db.close()
    return user


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login_page'))
        user = current_user()
        if user is None:
            session.clear()
            return redirect(url_for('login_page'))
        if user['is_banned']:
            session.clear()
            flash('تم طردك من المنصة', 'error')
            return redirect(url_for('login_page'))
        # لازم يختار دوره أولاً
        if not user['role_chosen'] and request.endpoint not in ('select_role','submit_role','logout','static'):
            return redirect(url_for('select_role'))
        return f(*args, **kwargs)
    return decorated


def role_required(*allowed):
    """يتطلب دوراً معيناً (admin / owner). يقبل قائمة أدوار."""
    def deco(f):
        @wraps(f)
        @login_required
        def w(*args, **kwargs):
            user = current_user()
            if user['role'] not in allowed:
                abort(403)
            return f(*args, **kwargs)
        return w
    return deco


def allowed_file(filename, allowed_set):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in allowed_set


# ════ تنظيف HTML من المحتوى الخبيث (XSS) ════
# Tags المسموح بها فقط (whitelist)
ALLOWED_HTML_TAGS = {
    'p', 'br', 'strong', 'b', 'em', 'i', 'u',
    'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
    'ul', 'ol', 'li', 'blockquote',
    'a', 'img', 'span', 'div'
}
# Attributes المسموح بها لكل tag
ALLOWED_HTML_ATTRS = {
    'a': {'href', 'title'},
    'img': {'src', 'alt', 'title'},
}

# Regex لإزالة scripts و event handlers و javascript: links
_SCRIPT_RE = re.compile(r'<script[^>]*>.*?</script>', re.IGNORECASE | re.DOTALL)
_STYLE_RE = re.compile(r'<style[^>]*>.*?</style>', re.IGNORECASE | re.DOTALL)
_ON_EVENT_RE = re.compile(r'\son\w+\s*=\s*"[^"]*"|\son\w+\s*=\s*\'[^\']*\'', re.IGNORECASE)
# يستبدل href="javascript:..." بـ href="#" كاملاً
_JS_HREF_RE = re.compile(r'href\s*=\s*(["\'])\s*javascript:[^"\']*\1', re.IGNORECASE)
_JS_SRC_RE = re.compile(r'src\s*=\s*(["\'])\s*javascript:[^"\']*\1', re.IGNORECASE)

def sanitize_html(html_text):
    """ينظف HTML من scripts/styles/event handlers/javascript: links.
       يحتفظ بالعلامات المسموح بها فقط."""
    if not html_text:
        return ''
    text = str(html_text)
    # امسح كل <script>...</script>
    text = _SCRIPT_RE.sub('', text)
    text = _STYLE_RE.sub('', text)
    # امسح كل on* handlers
    text = _ON_EVENT_RE.sub('', text)
    # امسح javascript: من href/src
    text = _JS_HREF_RE.sub('href="#"', text)
    text = _JS_SRC_RE.sub('src=""', text)
    # امسح iframe/object/embed/form (خطرة)
    text = re.sub(r'</?(?:iframe|object|embed|form|input|button|svg|math)[^>]*>',
                  '', text, flags=re.IGNORECASE)
    return text


# ════════════════════════════════════════════════════════════
# نظام توليد الصوت (Text-to-Speech) باستخدام edge-tts
# ════════════════════════════════════════════════════════════
# هل المكتبة متاحة؟
try:
    import edge_tts
    import asyncio
    EDGE_TTS_AVAILABLE = True
except ImportError:
    EDGE_TTS_AVAILABLE = False

# الأصوات العربية المتاحة (من Microsoft Edge TTS)
ARABIC_VOICES = [
    {'id': 'ar-SA-HamedNeural',    'name': 'حامد (رجل سعودي)',  'gender': 'M', 'dialect': 'سعودي'},
    {'id': 'ar-SA-ZariyahNeural',  'name': 'زاريا (امرأة سعودية)', 'gender': 'F', 'dialect': 'سعودي'},
    {'id': 'ar-EG-SalmaNeural',    'name': 'سلمى (امرأة مصرية)', 'gender': 'F', 'dialect': 'مصري'},
    {'id': 'ar-EG-ShakirNeural',   'name': 'شاكر (رجل مصري)',   'gender': 'M', 'dialect': 'مصري'},
    {'id': 'ar-AE-FatimaNeural',   'name': 'فاطمة (امرأة إماراتية)', 'gender': 'F', 'dialect': 'إماراتي'},
    {'id': 'ar-AE-HamdanNeural',   'name': 'حمدان (رجل إماراتي)', 'gender': 'M', 'dialect': 'إماراتي'},
    {'id': 'ar-IQ-RanaNeural',     'name': 'رنا (امرأة عراقية)', 'gender': 'F', 'dialect': 'عراقي'},
    {'id': 'ar-IQ-BasselNeural',   'name': 'باسل (رجل عراقي)',  'gender': 'M', 'dialect': 'عراقي'},
    {'id': 'ar-JO-SanaNeural',     'name': 'سناء (امرأة أردنية)', 'gender': 'F', 'dialect': 'أردني'},
    {'id': 'ar-JO-TaimNeural',     'name': 'تيم (رجل أردني)',    'gender': 'M', 'dialect': 'أردني'},
    {'id': 'ar-SY-AmanyNeural',    'name': 'أماني (امرأة سورية)', 'gender': 'F', 'dialect': 'شامي'},
    {'id': 'ar-SY-LaithNeural',    'name': 'ليث (رجل سوري)',    'gender': 'M', 'dialect': 'شامي'},
    {'id': 'ar-LB-LaylaNeural',    'name': 'ليلى (امرأة لبنانية)', 'gender': 'F', 'dialect': 'لبناني'},
    {'id': 'ar-LB-RamiNeural',     'name': 'رامي (رجل لبناني)', 'gender': 'M', 'dialect': 'لبناني'},
    {'id': 'ar-KW-NouraNeural',    'name': 'نورة (امرأة كويتية)', 'gender': 'F', 'dialect': 'كويتي'},
    {'id': 'ar-KW-FahedNeural',    'name': 'فهد (رجل كويتي)',   'gender': 'M', 'dialect': 'كويتي'},
    {'id': 'ar-DZ-AminaNeural',    'name': 'أمينة (امرأة جزائرية)', 'gender': 'F', 'dialect': 'جزائري'},
    {'id': 'ar-MA-MounaNeural',    'name': 'منى (امرأة مغربية)', 'gender': 'F', 'dialect': 'مغربي'},
    {'id': 'ar-TN-ReemNeural',     'name': 'ريم (امرأة تونسية)', 'gender': 'F', 'dialect': 'تونسي'},
    {'id': 'ar-YE-MaryamNeural',   'name': 'مريم (امرأة يمنية)', 'gender': 'F', 'dialect': 'يمني'},
]

DEFAULT_VOICE = 'ar-SA-HamedNeural'

def get_default_voice():
    """يقرأ الصوت الافتراضي من app_settings (المالك يستطيع تغييره)."""
    try:
        db = sqlite3.connect(DB)
        db.row_factory = sqlite3.Row
        row = db.execute("SELECT value FROM app_settings WHERE key='default_tts_voice'").fetchone()
        db.close()
        if row and row['value']:
            return row['value']
    except Exception:
        pass
    return DEFAULT_VOICE

def is_valid_voice(voice_id):
    """يتحقق إن الصوت في القائمة المسموحة."""
    return any(v['id'] == voice_id for v in ARABIC_VOICES)

def strip_html_to_text(html):
    """يحول HTML لنص نظيف للقراءة الصوتية."""
    if not html:
        return ''
    # إزالة img tags كاملاً
    text = re.sub(r'<img[^>]*>', ' ', html, flags=re.IGNORECASE)
    # تحويل بعض tags لأسطر جديدة
    text = re.sub(r'</?(?:h[1-6]|p|div|br|li)[^>]*>', '\n', text, flags=re.IGNORECASE)
    # إزالة بقية tags
    text = re.sub(r'<[^>]+>', '', text)
    # تنظيف
    text = text.replace('&nbsp;', ' ').replace('&amp;', '&').replace('&lt;', '<').replace('&gt;', '>').replace('&quot;', '"')
    text = re.sub(r'\n+', '. ', text)
    text = re.sub(r'\s+', ' ', text)
    return text.strip()

async def _generate_audio_async(text, voice_id, output_path):
    """يولّد ملف صوت من النص باستخدام edge-tts."""
    communicate = edge_tts.Communicate(text, voice_id)
    await communicate.save(output_path)

def generate_research_audio(rid, voice_id=None):
    """يولّد ملف صوتي لبحث كامل ويحدّث جدول research.
       يعيد (success: bool, audio_web_path: str, error_msg: str)."""
    if not EDGE_TTS_AVAILABLE:
        return False, '', 'مكتبة edge-tts غير مثبتة. شغّل: pip install edge-tts'

    voice_id = voice_id or get_default_voice()
    if not is_valid_voice(voice_id):
        voice_id = DEFAULT_VOICE

    db = sqlite3.connect(DB)
    db.row_factory = sqlite3.Row
    research = db.execute("SELECT * FROM research WHERE id=?", (rid,)).fetchone()
    if not research:
        db.close()
        return False, '', 'البحث غير موجود'

    # حضّر النص: العنوان + الملخص + المحتوى
    title = research['title'] or ''
    summary = research['summary'] or ''
    content_text = strip_html_to_text(research['content'] or '')
    full_text = f"{title}. {summary}. {content_text}"

    # حد عملي: ~60,000 حرف (~1 ساعة صوت). يقسّم أكبر من ذلك
    MAX_TTS_CHARS = 60000
    if len(full_text) > MAX_TTS_CHARS:
        full_text = full_text[:MAX_TTS_CHARS] + '...'

    if len(full_text.strip()) < 10:
        db.close()
        return False, '', 'النص قصير جداً للقراءة'

    # حدّث الحالة "جاري التوليد"
    db.execute("UPDATE research SET audio_status='generating' WHERE id=?", (rid,))
    db.commit()

    try:
        # امسح الملف القديم إن وُجد
        old_path = research['audio_file']
        if old_path and old_path.startswith('/static/uploads/audio/'):
            old_full = os.path.join(app.root_path, old_path.lstrip('/'))
            if os.path.exists(old_full):
                try: os.remove(old_full)
                except: pass

        # ولّد جديد
        filename = f"research_{rid}_{secrets.token_hex(6)}.mp3"
        output_path = os.path.join(AUDIO_DIR, filename)
        asyncio.run(_generate_audio_async(full_text, voice_id, output_path))

        # تأكد إن الملف أُنشئ
        if not os.path.exists(output_path) or os.path.getsize(output_path) < 100:
            db.execute("UPDATE research SET audio_status='failed' WHERE id=?", (rid,))
            db.commit()
            db.close()
            return False, '', 'فشل توليد الملف الصوتي'

        web_path = f"/static/uploads/audio/{filename}"
        db.execute("""UPDATE research SET audio_file=?, audio_voice=?, audio_status='ready'
                      WHERE id=?""", (web_path, voice_id, rid))
        db.commit()
        db.close()
        return True, web_path, ''
    except Exception as e:
        db.execute("UPDATE research SET audio_status='failed' WHERE id=?", (rid,))
        db.commit()
        db.close()
        return False, '', f'خطأ: {str(e)[:200]}'



def save_upload(file_storage, folder, allowed_set):
    """يحفظ الملف ويعيد المسار النسبي للويب، أو None.
       يتحقق من magic bytes للتأكد إن المحتوى مطابق للنوع."""
    if not file_storage or not file_storage.filename:
        return None, None
    if not allowed_file(file_storage.filename, allowed_set):
        return None, None
    ext = file_storage.filename.rsplit('.',1)[1].lower()

    # فحص magic bytes: المحتوى مطابق للنوع المدّعى
    if not verify_file_signature(file_storage, ext):
        return None, None

    safe_name = f"{secrets.token_hex(10)}.{ext}"
    folder_map = {
        'avatars': AVATAR_DIR,
        'news': NEWS_DIR,
        'research': RESEARCH_DIR,
        'books': BOOKS_DIR,
        'astro': ASTRO_DIR,
    }
    target_dir = folder_map.get(folder, AVATAR_DIR)
    target = os.path.join(target_dir, safe_name)
    file_storage.save(target)
    web_path = f"/static/uploads/{folder}/{safe_name}"
    return web_path, file_storage.filename


def notify(db, user_id, message, link=''):
    db.execute("INSERT INTO notifications(user_id,message,link) VALUES(?,?,?)",
               (user_id, message, link))


def security_log(db, user_id, action, details=''):
    """يسجل حدث أمني. مهم: لا يـcommit، الذي يستدعي يجب commit بعدها."""
    try:
        ip = request.remote_addr or 'unknown'
    except Exception:
        ip = 'unknown'
    try:
        db.execute("""INSERT INTO security_log(user_id, action, ip, details)
                      VALUES(?, ?, ?, ?)""",
                   (user_id, action, ip, details[:500] if details else ''))
    except Exception:
        pass


# ════ فحص ملفات بـmagic bytes (signatures) ════
FILE_SIGNATURES = {
    'png':  [b'\x89PNG\r\n\x1a\n'],
    'jpg':  [b'\xff\xd8\xff'],
    'jpeg': [b'\xff\xd8\xff'],
    'gif':  [b'GIF87a', b'GIF89a'],
    'webp': [b'RIFF'],  # نتأكد بـRIFF...WEBP
    'pdf':  [b'%PDF'],
}

def verify_file_signature(file_storage, expected_ext):
    """يقرأ أول 16 byte من الملف ويتحقق أن المحتوى يطابق النوع المدّعى.
       يعيد True إن مطابق أو لا يوجد توقيع معروف لهذه الصيغة."""
    if not file_storage:
        return False
    expected = expected_ext.lower().lstrip('.')
    sigs = FILE_SIGNATURES.get(expected)
    if not sigs:
        return True  # صيغة لا نعرف توقيعها → لا نمنع

    # احفظ الموضع، اقرأ، ارجع
    try:
        pos = file_storage.tell()
        header = file_storage.read(16)
        file_storage.seek(pos)
    except Exception:
        return False

    # webp تحقق إضافي: RIFF....WEBP
    if expected == 'webp':
        return header.startswith(b'RIFF') and b'WEBP' in header[:16]

    return any(header.startswith(s) for s in sigs)


def unread_count_for(db, uid):
    r = db.execute("SELECT COUNT(*) c FROM notifications WHERE user_id=? AND is_read=0",
                   (uid,)).fetchone()
    return r['c']


# يجعل بعض المتغيرات متاحة في كل القوالب
@app.context_processor
def inject_globals():
    user = current_user()
    # الأقسام تُجلب لكل صفحة (للسايدبار)
    try:
        db = get_db()
        all_cats = db.execute("SELECT * FROM categories ORDER BY sort_order, id").fetchall()
        db.close()
    except Exception:
        all_cats = []

    if user is None:
        return {'t': TRANSLATIONS['ar'], 'lang':'ar', 'theme':'dark',
                'user': None, 'render_md': render_md, 'all_categories': all_cats,
                'csrf_token': csrf_token, 'reading_time': reading_time}
    lang = user['lang'] or 'ar'
    return {
        't': TRANSLATIONS.get(lang, TRANSLATIONS['ar']),
        'lang': lang,
        'theme': user['theme'] or 'dark',
        'is_admin': user['role'] in ('admin','owner'),
        'is_owner': user['role'] == 'owner',
        'render_md': render_md,
        'all_categories': all_cats,
        'csrf_token': csrf_token,
        'reading_time': reading_time,
    }


# ══════════════════════════════════════
# المسارات - Routes
# ══════════════════════════════════════
@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('home'))
    return render_template('landing.html')


@app.route('/landing')
def landing():
    if 'user_id' in session:
        return redirect(url_for('home'))
    return render_template('landing.html')


@app.route('/login')
def login_page():
    """صفحة تسجيل الدخول (معرف + كلمة مرور)."""
    if 'user_id' in session:
        return redirect(url_for('home'))
    role = request.args.get('role', '')
    if role not in ('member','admin','owner'):
        role = 'member'
    return render_template('login_form.html', role=role, mode='login',
                           google_enabled=GOOGLE_ENABLED)


@app.route('/auth-choice')
def auth_choice():
    """الخطوة بين اختيار الدور وبين الدخول/التسجيل.
       تعرض زرين: تسجيل الدخول أو إنشاء حساب."""
    if 'user_id' in session:
        return redirect(url_for('home'))
    role = request.args.get('role', '')
    if role not in ('member','admin','owner'):
        role = 'member'
    return render_template('auth_choice.html', role=role)


@app.route('/register')
def register_page():
    """صفحة إنشاء حساب جديد."""
    if 'user_id' in session:
        return redirect(url_for('home'))
    role = request.args.get('role', '')
    if role not in ('member','admin','owner'):
        role = 'member'
    return render_template('login_form.html', role=role, mode='register',
                           google_enabled=GOOGLE_ENABLED)


@app.route('/auth/register', methods=['POST'])
def auth_register():
    """ينشئ حساب جديد بمعرف + اسم + كلمة مرور + دور."""
    username = (request.form.get('username') or '').strip().lower()
    name     = (request.form.get('name') or '').strip()
    password = request.form.get('password') or ''
    password2 = request.form.get('password2') or ''
    role     = request.form.get('role', 'member')
    code     = (request.form.get('code') or '').strip()

    if role not in ('member','admin','owner'):
        role = 'member'

    # التحقق من المدخلات
    import re as _re
    if not _re.match(r'^[a-zA-Z0-9_]{3,20}$', username):
        flash('المعرّف يجب أن يكون 3-20 حرف إنجليزي/رقم/_ فقط', 'error')
        return redirect(url_for('register_page', role=role))

    if not name or len(name) < 2:
        flash('الاسم قصير جداً', 'error')
        return redirect(url_for('register_page', role=role))

    if len(password) < 8:
        flash('كلمة المرور يجب 8 أحرف على الأقل', 'error')
        return redirect(url_for('register_page', role=role))

    # تحقق من قوة كلمة المرور: يجب أن تحوي حرف ورقم على الأقل
    has_letter = any(ch.isalpha() for ch in password)
    has_digit  = any(ch.isdigit() for ch in password)
    if not (has_letter and has_digit):
        flash('كلمة المرور يجب أن تحتوي على حرف ورقم على الأقل', 'error')
        return redirect(url_for('register_page', role=role))

    # كلمات شائعة جداً
    weak_passwords = {'12345678', 'password', 'qwerty12', '11111111',
                      'abcd1234', 'pass1234', '00000000'}
    if password.lower() in weak_passwords:
        flash('كلمة المرور ضعيفة جداً وشائعة، اختر كلمة أقوى', 'error')
        return redirect(url_for('register_page', role=role))

    if password != password2:
        flash('كلمتا المرور غير متطابقتين', 'error')
        return redirect(url_for('register_page', role=role))

    # المشرف/المالك يحتاج رمز
    if role in ('admin','owner'):
        expected = ROLE_CODES.get(role)
        if code != expected:
            flash('الرمز السري لهذا الدور غير صحيح', 'error')
            return redirect(url_for('register_page', role=role))

    db = get_db()
    # تحقق إن المعرف غير محجوز
    exists = db.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()
    if exists:
        db.close()
        flash('المعرّف محجوز، اختر معرّفاً آخر', 'error')
        return redirect(url_for('register_page', role=role))

    pw_hash = hash_password(password)
    db.execute("""INSERT INTO users(username, name, password_hash, role, role_chosen)
                  VALUES(?,?,?,?,1)""",
               (username, name, pw_hash, role))
    db.commit()
    user = db.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    db.close()

    session['user_id'] = user['id']
    flash(f'تم إنشاء حسابك بنجاح، أهلاً {name}', 'success')
    return redirect(url_for('home'))


@app.route('/auth/login', methods=['POST'])
def auth_login():
    """تسجيل دخول بمعرف + كلمة مرور مع حماية متدرّجة."""
    ip = request.remote_addr or 'unknown'

    # rate limit أساسي على الـIP (حماية عامة ضد flood)
    if rate_limit(f'login:{ip}', max_hits=20, window_sec=60):
        flash('محاولات كثيرة من جهازك، انتظر دقيقة ثم حاول', 'error')
        return redirect(url_for('login_page'))

    username = (request.form.get('username') or '').strip().lower()
    password = request.form.get('password') or ''

    if not username or not password:
        flash('المعرّف وكلمة المرور مطلوبان', 'error')
        return redirect(url_for('login_page'))

    # === تحقق من قفل الحساب بسبب محاولات سابقة ===
    # نتفقد على مفتاحين: username + IP (لمنع تجاوز الحماية بطريقتين)
    user_key = f'login_user:{username}'
    ip_key = f'login_ip:{ip}'

    locked_u, sec_u, fails_u = login_check_lockout(user_key)
    locked_i, sec_i, fails_i = login_check_lockout(ip_key)

    if locked_u or locked_i:
        wait = max(sec_u, sec_i)
        duration = format_duration_ar(wait)
        flash(f'تم قفل المحاولات مؤقتاً. حاول بعد {duration}', 'error')
        return redirect(url_for('login_page'))

    # === تحقق الـcredentials ===
    db = get_db()
    user = db.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()

    if not user or not user['password_hash'] or not verify_password(password, user['password_hash']):
        db.close()
        # سجل محاولة فاشلة على المفتاحين
        penalty_u, fails_u = login_record_fail(user_key)
        penalty_i, fails_i = login_record_fail(ip_key)
        penalty = max(penalty_u, penalty_i)
        fails = max(fails_u, fails_i)

        if penalty > 0:
            duration = format_duration_ar(penalty)
            flash(f'❌ المعرّف أو كلمة المرور خاطئة. (محاولة #{fails}) — قُفل الدخول لمدة {duration}',
                  'error')
        else:
            # كم محاولة باقية قبل القفل؟
            remaining = LOGIN_PENALTIES[0][0] - fails
            if remaining > 0:
                flash(f'❌ المعرّف أو كلمة المرور خاطئة. تبقى {remaining} {"محاولة" if remaining==1 else "محاولات"} قبل قفل مؤقت',
                      'error')
            else:
                flash('❌ المعرّف أو كلمة المرور غير صحيحة', 'error')

        return redirect(url_for('login_page'))

    if user['is_banned']:
        db.close()
        flash('حسابك محظور', 'error')
        return redirect(url_for('login_page'))

    db.close()

    # نجاح: امسح سجل المحاولات
    login_record_success(user_key)
    login_record_success(ip_key)

    # سجل أمني
    db = get_db()
    security_log(db, user['id'], 'login_success')
    db.commit()
    db.close()

    session['user_id'] = user['id']
    flash(f'أهلاً بعودتك، {user["name"]}', 'success')
    return redirect(url_for('home'))


# ── Google OAuth حقيقي ──
@app.route('/auth/google')
def google_login():
    if not GOOGLE_ENABLED:
        flash('Google OAuth غير مفعّل. أضف المفاتيح في .env', 'error')
        return redirect(url_for('login_page'))
    redirect_uri = url_for('google_callback', _external=True)
    return oauth.google.authorize_redirect(redirect_uri)


@app.route('/auth/google/callback')
def google_callback():
    if not GOOGLE_ENABLED:
        return redirect(url_for('login_page'))
    try:
        token = oauth.google.authorize_access_token()
        info  = token.get('userinfo') or oauth.google.parse_id_token(token, None)
    except Exception as e:
        flash(f'فشل تسجيل الدخول: {e}', 'error')
        return redirect(url_for('login_page'))

    email     = info.get('email')
    google_id = info.get('sub')
    name      = info.get('name') or (email or '').split('@')[0]
    picture   = info.get('picture') or '/static/img/default_avatar.png'

    if not email:
        flash('لم يُرسل البريد الإلكتروني من Google', 'error')
        return redirect(url_for('login_page'))

    db = get_db()
    user = db.execute("SELECT * FROM users WHERE google_id=? OR email=?",
                      (google_id, email)).fetchone()
    if user:
        db.execute("UPDATE users SET google_id=?, name=COALESCE(NULLIF(?,''),name) WHERE id=?",
                   (google_id, name, user['id']))
    else:
        base_un = (email.split('@')[0])[:20] or 'user'
        username = base_un
        i = 1
        while db.execute("SELECT id FROM users WHERE username=?",(username,)).fetchone():
            i += 1
            username = f"{base_un}{i}"
        db.execute("""INSERT INTO users(google_id,email,name,username,avatar)
                      VALUES(?,?,?,?,?)""",
                   (google_id, email, name, username, picture))
        user = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    db.commit()
    session['user_id'] = user['id']
    db.close()
    return redirect(url_for('select_role'))


# ── تسجيل دخول تجريبي (يبقى للاختبار) ──
@app.route('/auth/google/demo', methods=['POST'])
def google_demo_login():
    data = request.get_json() or {}
    email = data.get('email', 'demo@marsad.com')
    name  = data.get('name',  'مستخدم تجريبي')

    db = get_db()
    user = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    if not user:
        base_un = email.split('@')[0][:20]
        username = base_un
        i = 1
        while db.execute("SELECT id FROM users WHERE username=?",(username,)).fetchone():
            i += 1; username = f"{base_un}{i}"
        db.execute("INSERT INTO users(email,name,username) VALUES(?,?,?)",
                   (email, name, username))
        db.commit()
        user = db.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    db.close()
    session['user_id'] = user['id']
    return jsonify({'success': True})


@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('select_role'))


# ══════════════════════════════════════
# اختيار الدور (الخطوة الأولى)
# ══════════════════════════════════════
@app.route('/select-role')
def select_role():
    """الخطوة الأولى: اختيار الدور قبل التسجيل/الدخول.
       لو المستخدم داخل ولم يختر دوراً، يكمل اختيار. لو اختار، يذهب للرئيسية."""
    user = current_user() if 'user_id' in session else None
    if user and user['role_chosen']:
        return redirect(url_for('home'))
    return render_template('select_role.html', user=user)


@app.route('/select-role/submit', methods=['POST'])
def submit_role():
    """يُستخدم فقط للمستخدمين الذين دخلوا عبر Google ويحتاجون اختيار دور.
       للحالة الجديدة (تسجيل بمعرف/مرور) الدور يُختار في الفورم مباشرة."""
    if 'user_id' not in session:
        return redirect(url_for('select_role'))
    user = current_user()
    chosen = request.form.get('role','member')
    code   = (request.form.get('code') or '').strip()

    if chosen not in ('member','admin','owner'):
        chosen = 'member'

    # العضو لا يحتاج رمز، المشرف/المالك نعم
    if chosen in ('admin','owner'):
        expected = ROLE_CODES.get(chosen,'')
        if code != expected:
            flash('الرمز السري غير صحيح', 'error')
            return redirect(url_for('select_role'))

    db = get_db()
    db.execute("UPDATE users SET role=?, role_chosen=1 WHERE id=?",
               (chosen, user['id']))
    db.commit()
    db.close()
    flash(f'تم تأكيد دورك', 'success')
    return redirect(url_for('home'))


# ══════════════════════════════════════
# الإعدادات
# ══════════════════════════════════════
@app.route('/settings', methods=['GET','POST'])
@login_required
def settings():
    user = current_user()
    db = get_db()

    if request.method == 'POST':
        theme = request.form.get('theme','dark')
        lang  = request.form.get('lang','ar')
        if theme not in ('dark','light'): theme = 'dark'
        if lang  not in ('ar','en'):     lang  = 'ar'
        db.execute("UPDATE users SET theme=?, lang=? WHERE id=?",
                   (theme, lang, user['id']))
        db.commit()
        db.close()
        flash('تم حفظ الإعدادات', 'success')
        return redirect(url_for('settings'))

    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('settings.html', user=user, unread_count=unread)


# ══════════════════════════════════════
# تغيير كلمة المرور (للمالك والمشرفين)
# ══════════════════════════════════════
@app.route('/settings/password', methods=['GET','POST'])
@login_required
def change_password():
    """تغيير كلمة المرور:
       - العضو: يغير كلمته بنفسه (يحتاج كلمته الحالية)
       - المشرف: ممنوع (يطلب من المالك)
       - المالك: يغير كلمته أو كلمة أي مشرف."""
    user = current_user()

    # المشرف ممنوع
    if user['role'] == 'admin':
        flash('المشرف لا يستطيع تغيير كلمة مروره بنفسه. تواصل مع المالك', 'error')
        return redirect(url_for('settings'))

    db = get_db()
    is_owner = user['role'] == 'owner'

    # جلب قائمة المشرفين (فقط للمالك)
    admins = []
    if is_owner:
        admins = db.execute("""SELECT id, name, username FROM users
                                WHERE role='admin' AND is_banned=0
                                ORDER BY name""").fetchall()

    if request.method == 'POST':
        # rate limit: 5 محاولات/دقيقة
        if rate_limit(f'pwchange:{user["id"]}', max_hits=5, window_sec=60):
            db.close()
            flash('محاولات كثيرة، انتظر دقيقة', 'error')
            return redirect(url_for('change_password'))

        target_user_id = request.form.get('target_user_id', '').strip()
        owner_pw   = request.form.get('owner_password') or ''
        new_pw     = request.form.get('new_password') or ''
        confirm_pw = request.form.get('confirm_password') or ''

        # 1. تحقق كلمة مرور المالك (مطلوبة دائماً للتأكيد)
        if not user['password_hash']:
            db.close()
            flash('حسابك لا يحوي كلمة مرور. تواصل مع الدعم', 'error')
            return redirect(url_for('change_password'))

        if not verify_password(owner_pw, user['password_hash']):
            penalty, fails = login_record_fail(f'login_user:{user["username"]}')
            security_log(db, user['id'], 'password_change_failed',
                         f'wrong owner password, target={target_user_id}')
            db.commit()
            db.close()
            if penalty > 0:
                duration = format_duration_ar(penalty)
                flash(f'❌ كلمة مرورك خاطئة. (محاولة #{fails}) — قُفل المحاولات لمدة {duration}', 'error')
            else:
                remaining = LOGIN_PENALTIES[0][0] - fails
                if remaining > 0:
                    flash(f'❌ كلمة مرورك خاطئة. تبقى {remaining} محاولات', 'error')
                else:
                    flash('❌ كلمة مرورك غير صحيحة', 'error')
            return redirect(url_for('change_password'))

        # 2. حدد المستخدم المستهدف
        if not target_user_id or target_user_id == str(user['id']) or target_user_id == 'self':
            target_user = user
            is_self = True
        else:
            # العضو لا يستطيع تغيير كلمة غيره
            if not is_owner:
                db.close()
                flash('لا يمكنك تغيير كلمة مرور حساب آخر', 'error')
                return redirect(url_for('change_password'))

            try:
                tid = int(target_user_id)
                target_user = db.execute("SELECT * FROM users WHERE id=?", (tid,)).fetchone()
            except ValueError:
                target_user = None

            if not target_user:
                db.close()
                flash('المستخدم المستهدف غير موجود', 'error')
                return redirect(url_for('change_password'))

            # المالك يستطيع تغيير كلمة المشرفين فقط (ليس الأعضاء)
            if target_user['role'] != 'admin':
                db.close()
                flash('يمكنك تغيير كلمات المشرفين فقط (وكلمتك)', 'error')
                return redirect(url_for('change_password'))

            is_self = False

        # 3. تحقق من قوة كلمة المرور الجديدة
        if len(new_pw) < 8:
            db.close()
            flash('كلمة المرور الجديدة يجب 8 أحرف على الأقل', 'error')
            return redirect(url_for('change_password'))

        has_letter = any(ch.isalpha() for ch in new_pw)
        has_digit  = any(ch.isdigit() for ch in new_pw)
        if not (has_letter and has_digit):
            db.close()
            flash('كلمة المرور الجديدة يجب أن تحتوي على حرف ورقم على الأقل', 'error')
            return redirect(url_for('change_password'))

        weak_passwords = {'12345678', 'password', 'qwerty12', '11111111',
                          'abcd1234', 'pass1234', '00000000', 'password1',
                          'admin123', 'owner123', 'marsad12', '12345678a'}
        if new_pw.lower() in weak_passwords:
            db.close()
            flash('كلمة المرور ضعيفة جداً، اختر كلمة أقوى', 'error')
            return redirect(url_for('change_password'))

        # عند تغيير كلمة المالك لنفسه، تأكد أنها مختلفة عن الحالية
        if is_self and verify_password(new_pw, user['password_hash']):
            db.close()
            flash('كلمة المرور الجديدة لا يمكن أن تطابق الحالية', 'error')
            return redirect(url_for('change_password'))

        if new_pw != confirm_pw:
            db.close()
            flash('كلمتا المرور الجديدتين غير متطابقتين', 'error')
            return redirect(url_for('change_password'))

        # 4. احفظ
        new_hash = hash_password(new_pw)
        db.execute("UPDATE users SET password_hash=? WHERE id=?",
                   (new_hash, target_user['id']))

        # سجل أمني + إشعار للمشرف
        if is_self:
            security_log(db, user['id'], 'password_changed_self', '')
            login_record_success(f'login_user:{user["username"]}')
            success_msg = '✓ تم تغيير كلمة مرورك بنجاح'
        else:
            security_log(db, user['id'], 'password_changed_admin',
                         f'admin_id={target_user["id"]}, admin_username={target_user["username"]}')
            # إشعار للمشرف
            notify(db, target_user['id'],
                   f'🔐 تم تغيير كلمة مرورك من قبل المالك',
                   '/notifications')
            # امسح سجل محاولاته المقفلة
            login_record_success(f'login_user:{target_user["username"]}')
            success_msg = f'✓ تم تغيير كلمة مرور المشرف "{target_user["name"]}" بنجاح'

        db.commit()
        db.close()
        flash(success_msg, 'success')
        return redirect(url_for('change_password'))

    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('change_password.html', user=user, admins=admins,
                           is_owner=is_owner, unread_count=unread)


@app.route('/api/verify-password', methods=['POST'])
@login_required
def api_verify_password():
    """يتحقق من كلمة مرور المستخدم الحالي. يُستخدم لـ AJAX قبل العمليات الحساسة."""
    user = current_user()

    # rate limit صارم: 5 محاولات/دقيقة
    if rate_limit(f'verify_pw:{user["id"]}', max_hits=5, window_sec=60):
        return jsonify({'ok': False, 'error': 'rate_limited',
                        'message': 'محاولات كثيرة، انتظر دقيقة'}), 429

    data = request.get_json() or {}
    password = data.get('password', '')

    if not password:
        return jsonify({'ok': False, 'error': 'empty'}), 400

    if not user['password_hash']:
        return jsonify({'ok': False, 'error': 'no_password',
                        'message': 'حسابك لا يحوي كلمة مرور'}), 400

    if verify_password(password, user['password_hash']):
        # نخزن confirmation في session لـ 5 دقائق
        session['pw_confirmed_at'] = _time.time()
        return jsonify({'ok': True})

    return jsonify({'ok': False, 'error': 'wrong',
                    'message': 'كلمة المرور خاطئة'}), 401


def require_recent_password_confirm(max_age_sec=300):
    """يتحقق إن المستخدم أكد كلمة مروره مؤخراً (آخر 5 دقائق).
       يعيد True إن مؤكد، False إن لا."""
    confirmed_at = session.get('pw_confirmed_at', 0)
    return (_time.time() - confirmed_at) < max_age_sec


# AJAX سريع لتغيير الثيم/اللغة دون reload
@app.route('/api/settings', methods=['POST'])
@login_required
def api_settings():
    user = current_user()
    data = request.get_json() or {}
    theme = data.get('theme', user['theme'])
    lang  = data.get('lang',  user['lang'])
    if theme not in ('dark','light'): theme = 'dark'
    if lang  not in ('ar','en'):     lang  = 'ar'
    db = get_db()
    db.execute("UPDATE users SET theme=?, lang=? WHERE id=?", (theme, lang, user['id']))
    db.commit()
    db.close()
    return jsonify({'ok': True, 'theme': theme, 'lang': lang})


# ══════════════════════════════════════
# الرئيسية والملف الشخصي
# ══════════════════════════════════════
@app.route('/home')
@login_required
def home():
    user = current_user()
    db = get_db()

    # تبويب: my_feed (أبحاث من أتابعهم) أو discover (آخر الأبحاث)
    tab = request.args.get('tab', 'discover')
    if tab not in ('discover', 'my_feed'):
        tab = 'discover'

    # الأبحاث المثبتة (تظهر دائماً في الأعلى - بحد أقصى 5)
    pinned = db.execute("""
        SELECT r.*, u.name as author_name, u.avatar as author_avatar, u.username,
               c.name_ar as cat_name_ar, c.name_en as cat_name_en,
               c.slug as cat_slug, c.icon as cat_icon, c.color as cat_color
        FROM research r
        JOIN users u ON r.user_id=u.id
        LEFT JOIN categories c ON r.category_id=c.id
        WHERE r.is_featured=1 AND r.status='approved'
        ORDER BY r.created_at DESC LIMIT 5
    """).fetchall()
    pinned_ids = [p['id'] for p in pinned]

    if tab == 'my_feed':
        # أبحاث من الأشخاص الذين أتابعهم فقط (نستثني المثبتة لتجنب التكرار)
        if pinned_ids:
            placeholders = ','.join('?' * len(pinned_ids))
            top_research = db.execute(f"""
                SELECT r.*, u.name as author_name, u.avatar as author_avatar, u.username,
                       c.name_ar as cat_name_ar, c.name_en as cat_name_en,
                       c.slug as cat_slug, c.icon as cat_icon, c.color as cat_color
                FROM research r
                JOIN users u ON r.user_id=u.id
                LEFT JOIN categories c ON r.category_id=c.id
                JOIN follows f ON f.followed_id = r.user_id
                WHERE r.status='approved' AND f.follower_id=?
                  AND r.id NOT IN ({placeholders})
                ORDER BY r.created_at DESC LIMIT 10
            """, [user['id']] + pinned_ids).fetchall()
        else:
            top_research = db.execute("""
                SELECT r.*, u.name as author_name, u.avatar as author_avatar, u.username,
                       c.name_ar as cat_name_ar, c.name_en as cat_name_en,
                       c.slug as cat_slug, c.icon as cat_icon, c.color as cat_color
                FROM research r
                JOIN users u ON r.user_id=u.id
                LEFT JOIN categories c ON r.category_id=c.id
                JOIN follows f ON f.followed_id = r.user_id
                WHERE r.status='approved' AND f.follower_id=?
                ORDER BY r.created_at DESC LIMIT 10
            """, (user['id'],)).fetchall()
    else:
        # discover: آخر الأبحاث (نستثني المثبتة)
        if pinned_ids:
            placeholders = ','.join('?' * len(pinned_ids))
            top_research = db.execute(f"""
                SELECT r.*, u.name as author_name, u.avatar as author_avatar, u.username,
                       c.name_ar as cat_name_ar, c.name_en as cat_name_en,
                       c.slug as cat_slug, c.icon as cat_icon, c.color as cat_color
                FROM research r
                JOIN users u ON r.user_id=u.id
                LEFT JOIN categories c ON r.category_id=c.id
                WHERE r.status='approved' AND r.id NOT IN ({placeholders})
                ORDER BY r.created_at DESC LIMIT 10
            """, pinned_ids).fetchall()
        else:
            top_research = db.execute("""
                SELECT r.*, u.name as author_name, u.avatar as author_avatar, u.username,
                       c.name_ar as cat_name_ar, c.name_en as cat_name_en,
                       c.slug as cat_slug, c.icon as cat_icon, c.color as cat_color
                FROM research r
                JOIN users u ON r.user_id=u.id
                LEFT JOIN categories c ON r.category_id=c.id
                WHERE r.status='approved'
                ORDER BY r.created_at DESC LIMIT 10
            """).fetchall()

    latest_news = db.execute("""
        SELECT n.*, u.name as author_name
        FROM news n JOIN users u ON n.user_id=u.id
        ORDER BY n.created_at DESC LIMIT 5
    """).fetchall()

    # عدد الناس الذين أتابعهم
    following_count = db.execute("SELECT COUNT(*) as c FROM follows WHERE follower_id=?",
                                  (user['id'],)).fetchone()['c']

    unread = unread_count_for(db, user['id'])
    db.close()
    rank = get_rank(user['points'])
    return render_template('home.html', user=user, rank=rank,
                           top_research=top_research,
                           pinned=pinned,
                           latest_news=latest_news,
                           unread_count=unread,
                           tab=tab, following_count=following_count)


@app.route('/profile/<int:uid>')
@login_required
def profile(uid):
    me = current_user()
    db = get_db()
    prof = db.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not prof:
        db.close(); return "المستخدم غير موجود", 404

    is_own = (me['id'] == uid)

    # تبويب نشط
    tab = request.args.get('tab', 'approved')
    if tab not in ('approved', 'pending', 'rejected'):
        tab = 'approved'

    # غير صاحب الملف الشخصي يرى المعتمد فقط
    if not is_own and me['role'] not in ('admin','owner'):
        tab = 'approved'

    user_research = db.execute("""
        SELECT r.*, c.name_ar as cat_name_ar, c.name_en as cat_name_en,
               c.icon as cat_icon, c.color as cat_color
        FROM research r LEFT JOIN categories c ON r.category_id=c.id
        WHERE r.user_id=? AND r.status=?
        ORDER BY r.created_at DESC
    """, (uid, tab)).fetchall()

    # عدد الأبحاث في كل حالة (فقط لصاحب الملف أو الإدارة)
    counts = {'approved': 0, 'pending': 0, 'rejected': 0}
    if is_own or me['role'] in ('admin','owner'):
        rows = db.execute("""SELECT status, COUNT(*) as c FROM research
                             WHERE user_id=? GROUP BY status""", (uid,)).fetchall()
        for row in rows:
            if row['status'] in counts:
                counts[row['status']] = row['c']
    else:
        counts['approved'] = db.execute("""SELECT COUNT(*) as c FROM research
                                           WHERE user_id=? AND status='approved'""",
                                        (uid,)).fetchone()['c']

    # أعداد المتابعين والمتابَعين
    followers = db.execute("SELECT COUNT(*) as c FROM follows WHERE followed_id=?",
                           (uid,)).fetchone()['c']
    following = db.execute("SELECT COUNT(*) as c FROM follows WHERE follower_id=?",
                           (uid,)).fetchone()['c']

    # هل المستخدم الحالي يتابع هذا الملف؟
    is_following = False
    if not is_own:
        f = db.execute("SELECT 1 FROM follows WHERE follower_id=? AND followed_id=?",
                       (me['id'], uid)).fetchone()
        is_following = bool(f)

    unread = unread_count_for(db, me['id'])
    db.close()
    rank = get_rank(prof['points'])
    return render_template('profile.html', prof=prof, rank=rank,
                           user_research=user_research, user=me,
                           unread_count=unread, is_own=is_own,
                           tab=tab, counts=counts,
                           followers=followers, following=following,
                           is_following=is_following)


@app.route('/profile/edit', methods=['GET','POST'])
@login_required
def edit_profile():
    user = current_user()
    db = get_db()

    if request.method == 'POST':
        name     = request.form.get('name','').strip()
        username = request.form.get('username','').strip()
        bio      = request.form.get('bio','').strip()

        # تحقق من اليوزر الفريد
        if username:
            exist = db.execute("SELECT id FROM users WHERE username=? AND id!=?",
                               (username, user['id'])).fetchone()
            if exist:
                flash('اسم المستخدم محجوز، اختر اسماً آخر', 'error')
                db.close()
                return redirect(url_for('edit_profile'))

        # رفع الصورة (اختياري)
        # 1. أولوية لـ avatar_cropped (الصورة المقتصة كـ base64 من Cropper.js)
        # 2. fallback لرفع ملف عادي إن وُجد (للتوافق)
        avatar_path = user['avatar']
        cropped = (request.form.get('avatar_cropped') or '').strip()

        if cropped and cropped.startswith('data:image/'):
            try:
                import base64
                header, b64data = cropped.split(',', 1)
                # نوع الصورة من header مثل: data:image/jpeg;base64
                if 'jpeg' in header or 'jpg' in header: ext = 'jpg'
                elif 'png' in header: ext = 'png'
                elif 'webp' in header: ext = 'webp'
                else: ext = 'jpg'
                img_bytes = base64.b64decode(b64data)
                if len(img_bytes) > MAX_UPLOAD_MB * 1024 * 1024:
                    flash('الصورة المقتصة أكبر من الحد المسموح', 'error')
                else:
                    safe_name = f"{secrets.token_hex(10)}.{ext}"
                    target = os.path.join(AVATAR_DIR, safe_name)
                    with open(target, 'wb') as fh:
                        fh.write(img_bytes)
                    avatar_path = f"/static/uploads/avatars/{safe_name}"
            except Exception as e:
                flash(f'فشل حفظ الصورة المقتصة: {e}', 'error')
        elif 'avatar' in request.files:
            f = request.files['avatar']
            if f and f.filename:
                web, _ = save_upload(f, 'avatars', ALLOWED_IMG)
                if web:
                    avatar_path = web
                else:
                    flash('صيغة الصورة غير مدعومة (PNG/JPG/GIF/WEBP)', 'error')

        # === صورة الغلاف (cover) ===
        cover_path = user['cover_image'] or ''

        # حذف الغلاف؟
        if request.form.get('remove_cover') == '1':
            cover_path = ''

        # 1. أولوية لـ cover_cropped (Cropper.js)
        cover_cropped = (request.form.get('cover_cropped') or '').strip()
        if cover_cropped and cover_cropped.startswith('data:image/'):
            try:
                import base64
                header, b64data = cover_cropped.split(',', 1)
                if 'jpeg' in header or 'jpg' in header: ext = 'jpg'
                elif 'png' in header: ext = 'png'
                elif 'webp' in header: ext = 'webp'
                else: ext = 'jpg'
                img_bytes = base64.b64decode(b64data)
                if len(img_bytes) > MAX_UPLOAD_MB * 1024 * 1024:
                    flash('صورة الغلاف أكبر من الحد المسموح', 'error')
                else:
                    safe_name = f"cover_{secrets.token_hex(10)}.{ext}"
                    target = os.path.join(AVATAR_DIR, safe_name)
                    with open(target, 'wb') as fh:
                        fh.write(img_bytes)
                    cover_path = f"/static/uploads/avatars/{safe_name}"
            except Exception as e:
                flash(f'فشل حفظ الغلاف: {e}', 'error')
        elif 'cover_image' in request.files:
            # رفع عادي بدون cropper (الصورة كما هي بحجمها الأصلي)
            f = request.files['cover_image']
            if f and f.filename:
                web, _ = save_upload(f, 'avatars', ALLOWED_IMG)
                if web:
                    cover_path = web

        db.execute("""UPDATE users SET name=?, username=?, bio=?, avatar=?, cover_image=?
                      WHERE id=?""",
                   (name, username or user['username'], bio, avatar_path,
                    cover_path, user['id']))
        db.commit()
        flash('تم تحديث الملف الشخصي', 'success')
        db.close()
        return redirect(url_for('profile', uid=user['id']))

    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('edit_profile.html', user=user, unread_count=unread)


# ══════════════════════════════════════
# الأبحاث
# ══════════════════════════════════════
@app.route('/research')
@login_required
def research_list():
    user = current_user()
    db = get_db()
    tag = request.args.get('tag','')
    cat_slug = request.args.get('category','')

    # ترقيم الصفحات
    PER_PAGE = 20
    try:
        page = max(1, int(request.args.get('page', 1)))
    except ValueError:
        page = 1

    where = " WHERE r.status='approved' "
    params = []
    if cat_slug:
        where += " AND c.slug=? "
        params.append(cat_slug)
    if tag:
        where += " AND r.tags LIKE ? "
        params.append(f'%{tag}%')

    # عدّ إجمالي
    count_q = f"""SELECT COUNT(*) as c FROM research r
                  LEFT JOIN categories c ON r.category_id=c.id
                  {where}"""
    total = db.execute(count_q, params).fetchone()['c']
    total_pages = max(1, (total + PER_PAGE - 1) // PER_PAGE)
    if page > total_pages:
        page = total_pages

    offset = (page - 1) * PER_PAGE

    list_q = f"""SELECT r.*, u.name as author_name, u.avatar as author_avatar, u.username,
                        c.name_ar as cat_name_ar, c.name_en as cat_name_en,
                        c.slug as cat_slug, c.icon as cat_icon, c.color as cat_color
                 FROM research r
                 JOIN users u ON r.user_id=u.id
                 LEFT JOIN categories c ON r.category_id=c.id
                 {where}
                 ORDER BY r.created_at DESC
                 LIMIT ? OFFSET ?"""
    rows = db.execute(list_q, params + [PER_PAGE, offset]).fetchall()

    # القسم النشط (للعرض في العنوان)
    active_cat = None
    if cat_slug:
        active_cat = db.execute("SELECT * FROM categories WHERE slug=?", (cat_slug,)).fetchone()

    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('research.html', user=user, rows=rows,
                           unread_count=unread, active_tag=tag,
                           active_cat=active_cat,
                           page=page, total_pages=total_pages, total=total)


@app.route('/research/new', methods=['GET','POST'])
@login_required
def new_research():
    user = current_user()
    db = get_db()

    if request.method == 'POST':
        title    = request.form.get('title','').strip()
        summary  = request.form.get('summary','').strip()
        content  = sanitize_html(request.form.get('content','').strip())
        tags     = request.form.get('tags','').strip()
        cat_id   = request.form.get('category_id','').strip()

        if not (title and summary and content):
            flash('جميع الحقول مطلوبة', 'error')
            db.close()
            return redirect(url_for('new_research'))

        # القسم إلزامي
        if not cat_id:
            flash('يجب اختيار قسم للبحث', 'error')
            db.close()
            return redirect(url_for('new_research'))

        # تحقق إن القسم موجود
        try:
            cat_id = int(cat_id)
            cat_row = db.execute("SELECT id FROM categories WHERE id=?", (cat_id,)).fetchone()
            if not cat_row:
                flash('القسم المختار غير موجود', 'error')
                db.close()
                return redirect(url_for('new_research'))
        except ValueError:
            flash('قسم غير صالح', 'error')
            db.close()
            return redirect(url_for('new_research'))

        # صورة غلاف اختيارية - الأولوية لـ cropper
        cover_image = ''
        cover_cropped = (request.form.get('cover_cropped') or '').strip()
        if cover_cropped and cover_cropped.startswith('data:image/'):
            try:
                import base64
                header, b64data = cover_cropped.split(',', 1)
                if 'jpeg' in header or 'jpg' in header: ext = 'jpg'
                elif 'png' in header: ext = 'png'
                elif 'webp' in header: ext = 'webp'
                else: ext = 'jpg'
                img_bytes = base64.b64decode(b64data)
                if len(img_bytes) > MAX_UPLOAD_MB * 1024 * 1024:
                    flash('صورة الغلاف أكبر من الحد المسموح', 'error')
                else:
                    safe_name = f"rcover_{secrets.token_hex(10)}.{ext}"
                    target = os.path.join(RESEARCH_DIR, safe_name)
                    with open(target, 'wb') as fh:
                        fh.write(img_bytes)
                    cover_image = f"/static/uploads/research/{safe_name}"
            except Exception as e:
                flash(f'فشل حفظ الغلاف: {e}', 'error')
        elif 'cover_image' in request.files:
            f = request.files['cover_image']
            if f and f.filename:
                web, _ = save_upload(f, 'research', ALLOWED_IMG)
                if web:
                    cover_image = web
                else:
                    flash('صيغة الصورة غير مدعومة', 'error')

        # ملف PDF اختياري
        pdf_file_web = ''
        if 'pdf_file' in request.files:
            pf = request.files['pdf_file']
            if pf and pf.filename:
                ext = pf.filename.rsplit('.',1)[-1].lower() if '.' in pf.filename else ''
                if ext != 'pdf':
                    flash('ملف البحث يجب أن يكون PDF', 'error')
                    db.close()
                    return redirect(url_for('new_research'))
                if not verify_file_signature(pf, 'pdf'):
                    flash('الملف ليس PDF صالح', 'error')
                    db.close()
                    return redirect(url_for('new_research'))
                safe_name = f"{secrets.token_hex(10)}.pdf"
                target = os.path.join(RESEARCH_DIR, safe_name)
                pf.save(target)
                size = os.path.getsize(target)
                if size > 50 * 1024 * 1024:   # 50MB حد
                    os.remove(target)
                    flash('حجم PDF أكبر من 50MB', 'error')
                    db.close()
                    return redirect(url_for('new_research'))
                pdf_file_web = f'/static/uploads/research/{safe_name}'

        # المالك والمشرف ينشرون مباشرة، الأعضاء ترسل للمراجعة
        if user['role'] in ('admin','owner'):
            status = 'approved'
        else:
            status = 'pending'

        db.execute("""INSERT INTO research(user_id,category_id,title,summary,content,tags,cover_image,pdf_file,status)
                      VALUES(?,?,?,?,?,?,?,?,?)""",
                   (user['id'], cat_id, title, summary, content, tags, cover_image, pdf_file_web, status))
        rid = db.execute("SELECT last_insert_rowid()").fetchone()[0]

        # صور المعرض (متعددة)
        gallery = request.files.getlist('gallery_images')
        sort = 0
        for img_file in gallery[:10]:  # حد أقصى 10 صور
            if img_file and img_file.filename:
                web, _ = save_upload(img_file, 'research', ALLOWED_IMG)
                if web:
                    db.execute("""INSERT INTO research_images(research_id,image,sort_order)
                                  VALUES(?,?,?)""", (rid, web, sort))
                    sort += 1

        if status == 'approved':
            db.execute("UPDATE users SET points=points+1 WHERE id=?", (user['id'],))
            others = db.execute("SELECT id FROM users WHERE id!=?", (user['id'],)).fetchall()
            for u in others:
                notify(db, u['id'], f'بحث جديد: {title}', f'/research/{rid}')
            flash('تم نشر البحث (+1 نقطة)', 'success')
        else:
            # إشعار لكل المشرفين/المالك
            mods = db.execute("SELECT id FROM users WHERE role IN ('admin','owner')").fetchall()
            for m in mods:
                notify(db, m['id'], f'بحث جديد بانتظار المراجعة: {title}', '/admin/pending')
            flash('تم إرسال البحث للمشرفين للمراجعة', 'success')

        db.commit()
        db.close()
        return redirect(url_for('research_list'))

    # GET: اعرض النموذج مع قائمة الأقسام
    categories = db.execute("SELECT * FROM categories ORDER BY sort_order, id").fetchall()
    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('new_research.html', user=user, unread_count=unread,
                           categories=categories)


@app.route('/research/<int:rid>')
@login_required
def view_research(rid):
    user = current_user()
    db = get_db()
    r = db.execute("""
        SELECT r.*, u.name as author_name, u.avatar as author_avatar, u.username, u.points as author_points,
               c.name_ar as cat_name_ar, c.name_en as cat_name_en,
               c.slug as cat_slug, c.icon as cat_icon, c.color as cat_color
        FROM research r
        JOIN users u ON r.user_id=u.id
        LEFT JOIN categories c ON r.category_id=c.id
        WHERE r.id=?
    """, (rid,)).fetchone()
    if not r:
        db.close(); return "البحث غير موجود", 404

    # الأبحاث المعلقة لا يراها إلا صاحبها والمشرفون/المالك
    if r['status'] != 'approved' and user['id'] != r['user_id'] and user['role'] not in ('admin','owner'):
        db.close()
        abort(403)

    db.execute("UPDATE research SET views=views+1 WHERE id=?", (rid,))
    db.commit()

    liked = db.execute("SELECT id FROM likes WHERE user_id=? AND research_id=?",
                       (user['id'], rid)).fetchone()

    # هل البحث في مفضلة المستخدم؟
    bookmarked = db.execute("SELECT id FROM bookmarks WHERE user_id=? AND research_id=?",
                            (user['id'], rid)).fetchone()

    # كل التعليقات
    all_comments = db.execute("""
        SELECT c.*, u.name as author_name, u.avatar as author_avatar, u.username
        FROM comments c JOIN users u ON c.user_id=u.id
        WHERE c.research_id=? ORDER BY c.created_at ASC
    """, (rid,)).fetchall()

    # نبني شجرة: التعليقات الرئيسية + ردودها
    parents = []
    replies_map = {}  # parent_id -> [reply, reply, ...]
    for cm in all_comments:
        if cm['parent_id'] is None:
            parents.append(dict(cm))
        else:
            replies_map.setdefault(cm['parent_id'], []).append(dict(cm))

    # ألحق الردود بكل تعليق رئيسي
    for p in parents:
        p['replies'] = replies_map.get(p['id'], [])

    gallery = db.execute("""
        SELECT * FROM research_images WHERE research_id=?
        ORDER BY sort_order, id
    """, (rid,)).fetchall()

    # ════ أبحاث مشابهة (نفس القسم + تطابق الوسوم/العنوان) ════
    similar = []
    # 1) أولوية: نفس القسم
    if r['category_id']:
        similar = db.execute("""
            SELECT r.id, r.title, r.summary, r.cover_image, r.views, r.likes,
                   u.name as author_name, u.username as author_username,
                   c.name_ar as cat_name_ar, c.color as cat_color, c.icon as cat_icon
            FROM research r
            JOIN users u ON r.user_id=u.id
            LEFT JOIN categories c ON r.category_id=c.id
            WHERE r.status='approved' AND r.id != ? AND r.category_id=?
            ORDER BY r.views DESC
            LIMIT 8
        """, (rid, r['category_id'])).fetchall()

    # 2) إن لم نجد كفاية، نضيف من الوسوم المشتركة
    if len(similar) < 4 and r['tags']:
        existing_ids = {s['id'] for s in similar}
        existing_ids.add(rid)
        tag_words = [t.strip() for t in r['tags'].split(',') if t.strip()]
        for tag in tag_words[:5]:
            if len(similar) >= 8:
                break
            extra = db.execute("""
                SELECT r.id, r.title, r.summary, r.cover_image, r.views, r.likes,
                       u.name as author_name, u.username as author_username,
                       c.name_ar as cat_name_ar, c.color as cat_color, c.icon as cat_icon
                FROM research r
                JOIN users u ON r.user_id=u.id
                LEFT JOIN categories c ON r.category_id=c.id
                WHERE r.status='approved' AND r.tags LIKE ?
                ORDER BY r.views DESC LIMIT 5
            """, (f'%{tag}%',)).fetchall()
            for e in extra:
                if e['id'] not in existing_ids:
                    similar.append(e)
                    existing_ids.add(e['id'])
                    if len(similar) >= 8:
                        break

    # 3) لا يزال قليلاً؟ أضف الأكثر مشاهدة
    if len(similar) < 4:
        existing_ids = {s['id'] for s in similar}
        existing_ids.add(rid)
        popular = db.execute("""
            SELECT r.id, r.title, r.summary, r.cover_image, r.views, r.likes,
                   u.name as author_name, u.username as author_username,
                   c.name_ar as cat_name_ar, c.color as cat_color, c.icon as cat_icon
            FROM research r
            JOIN users u ON r.user_id=u.id
            LEFT JOIN categories c ON r.category_id=c.id
            WHERE r.status='approved' AND r.id != ?
            ORDER BY r.views DESC LIMIT 10
        """, (rid,)).fetchall()
        for p in popular:
            if p['id'] not in existing_ids:
                similar.append(p)
                existing_ids.add(p['id'])
                if len(similar) >= 6:
                    break

    similar = similar[:6]   # حد أقصى 6 بطاقات

    # هل المستخدم يتابع صاحب البحث؟
    is_following_author = False
    if user['id'] != r['user_id']:
        f = db.execute("SELECT 1 FROM follows WHERE follower_id=? AND followed_id=?",
                       (user['id'], r['user_id'])).fetchone()
        is_following_author = bool(f)

    unread = unread_count_for(db, user['id'])
    db.close()
    author_rank = get_rank(r['author_points'])

    # هل يستطيع توليد الصوت؟ (المؤلف أو الإدارة + edge-tts متاحة)
    can_generate_audio = EDGE_TTS_AVAILABLE and (
        r['user_id'] == user['id'] or user['role'] in ('admin', 'owner')
    )

    return render_template('view_research.html', user=user, r=r,
                           liked=bool(liked), bookmarked=bool(bookmarked),
                           unread_count=unread,
                           author_rank=author_rank, comments=parents,
                           gallery=gallery, similar=similar,
                           arabic_voices=ARABIC_VOICES,
                           default_voice=get_default_voice(),
                           can_generate_audio=can_generate_audio,
                           is_following_author=is_following_author)


@app.route('/research/<int:rid>/comment', methods=['POST'])
@login_required
def add_comment(rid):
    user = current_user()
    # rate limit: 5 تعليقات/دقيقة
    if rate_limit(f'comment:{user["id"]}', max_hits=5, window_sec=60):
        flash('أبطئ قليلاً، أرسلت تعليقات كثيرة في وقت قصير', 'error')
        return redirect(url_for('view_research', rid=rid))

    content = (request.form.get('content') or '').strip()
    if not content:
        flash('التعليق فارغ', 'error')
        return redirect(url_for('view_research', rid=rid))
    if len(content) > 1000:
        content = content[:1000]

    db = get_db()
    r = db.execute("SELECT user_id, title FROM research WHERE id=?", (rid,)).fetchone()
    if not r:
        db.close(); abort(404)
    db.execute("INSERT INTO comments(research_id,user_id,content) VALUES(?,?,?)",
               (rid, user['id'], content))
    # إشعار لصاحب البحث (إن لم يكن المعلّق نفسه)
    if r['user_id'] != user['id']:
        notify(db, r['user_id'],
               f'تعليق جديد على بحثك: {r["title"]}',
               f'/research/{rid}')
    db.commit()
    db.close()
    return redirect(url_for('view_research', rid=rid) + '#comments')


@app.route('/research/<int:rid>/comment/<int:cid>/delete', methods=['POST'])
@login_required
def delete_comment(rid, cid):
    user = current_user()
    db = get_db()
    c = db.execute("SELECT * FROM comments WHERE id=? AND research_id=?", (cid, rid)).fetchone()
    if not c:
        db.close(); abort(404)
    # المالك/المشرف أو صاحب التعليق
    if user['role'] not in ('admin','owner') and c['user_id'] != user['id']:
        db.close(); abort(403)
    db.execute("DELETE FROM comments WHERE id=?", (cid,))
    db.commit()
    db.close()
    return redirect(url_for('view_research', rid=rid) + '#comments')


@app.route('/research/<int:rid>/comment/<int:cid>/edit', methods=['POST'])
@login_required
def edit_comment(rid, cid):
    """تعديل تعليق أو رد. AJAX يرد JSON، فورم عادي يرد redirect."""
    user = current_user()
    new_content = (request.form.get('content') or '').strip()
    is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    if not new_content:
        if is_ajax:
            return jsonify({'error':'empty'}), 400
        flash('التعليق فارغ', 'error')
        return redirect(url_for('view_research', rid=rid))

    if len(new_content) > 1000:
        new_content = new_content[:1000]

    db = get_db()
    c = db.execute("SELECT * FROM comments WHERE id=? AND research_id=?",
                   (cid, rid)).fetchone()
    if not c:
        db.close()
        if is_ajax:
            return jsonify({'error':'not_found'}), 404
        abort(404)

    # فقط صاحب التعليق يستطيع تعديله (المشرف يحذف فقط لا يعدل)
    if c['user_id'] != user['id']:
        db.close()
        if is_ajax:
            return jsonify({'error':'forbidden'}), 403
        abort(403)

    # rate limit: 10 تعديلات/دقيقة
    if rate_limit(f'edit_comment:{user["id"]}', max_hits=10, window_sec=60):
        db.close()
        if is_ajax:
            return jsonify({'error':'rate_limited'}), 429
        flash('عدد كبير من التعديلات في وقت قصير', 'error')
        return redirect(url_for('view_research', rid=rid))

    db.execute("UPDATE comments SET content=? WHERE id=?", (new_content, cid))
    db.commit()
    db.close()

    if is_ajax:
        return jsonify({'ok': True, 'content': new_content})
    flash('تم تحديث التعليق', 'success')
    return redirect(url_for('view_research', rid=rid) + f'#c{cid}')


@app.route('/research/<int:rid>/like', methods=['POST'])
@login_required
def like_research(rid):
    user = current_user()
    db = get_db()
    existing = db.execute("SELECT id FROM likes WHERE user_id=? AND research_id=?",
                          (user['id'], rid)).fetchone()
    if existing:
        db.execute("DELETE FROM likes WHERE user_id=? AND research_id=?", (user['id'], rid))
        db.execute("UPDATE research SET likes=likes-1 WHERE id=?", (rid,))
        liked = False
    else:
        db.execute("INSERT INTO likes(user_id,research_id) VALUES(?,?)", (user['id'], rid))
        db.execute("UPDATE research SET likes=likes+1 WHERE id=?", (rid,))
        liked = True
    db.commit()
    count = db.execute("SELECT likes FROM research WHERE id=?", (rid,)).fetchone()['likes']
    db.close()
    return jsonify({'liked': liked, 'count': count})


# ══════════════════════════════════════
# تعديل وحذف البحث (للمشرفين والمالك فقط)
# ══════════════════════════════════════
@app.route('/research/<int:rid>/edit', methods=['GET','POST'])
@role_required('admin','owner')
def edit_research(rid):
    user = current_user()
    db = get_db()
    r = db.execute("SELECT * FROM research WHERE id=?", (rid,)).fetchone()
    if not r:
        db.close()
        return "البحث غير موجود", 404

    if request.method == 'POST':
        title    = request.form.get('title','').strip()
        summary  = request.form.get('summary','').strip()
        content  = sanitize_html(request.form.get('content','').strip())
        tags     = request.form.get('tags','').strip()
        cat_id   = request.form.get('category_id','').strip()

        if not (title and summary and content):
            flash('جميع الحقول الأساسية مطلوبة', 'error')
            db.close()
            return redirect(url_for('edit_research', rid=rid))

        # القسم إلزامي
        if not cat_id:
            flash('يجب اختيار قسم للبحث', 'error')
            db.close()
            return redirect(url_for('edit_research', rid=rid))

        try:
            cat_id = int(cat_id)
            cat_check = db.execute("SELECT id FROM categories WHERE id=?", (cat_id,)).fetchone()
            if not cat_check:
                flash('القسم غير موجود', 'error')
                db.close()
                return redirect(url_for('edit_research', rid=rid))
        except ValueError:
            flash('قسم غير صالح', 'error')
            db.close()
            return redirect(url_for('edit_research', rid=rid))

        # صورة غلاف جديدة (اختياري)
        cover_image = r['cover_image']  # الافتراضي: نُبقي الصورة القديمة
        cover_cropped = (request.form.get('cover_cropped') or '').strip()
        if cover_cropped and cover_cropped.startswith('data:image/'):
            try:
                import base64
                header, b64data = cover_cropped.split(',', 1)
                if 'jpeg' in header or 'jpg' in header: ext = 'jpg'
                elif 'png' in header: ext = 'png'
                elif 'webp' in header: ext = 'webp'
                else: ext = 'jpg'
                img_bytes = base64.b64decode(b64data)
                if len(img_bytes) <= MAX_UPLOAD_MB * 1024 * 1024:
                    safe_name = f"rcover_{secrets.token_hex(10)}.{ext}"
                    target = os.path.join(RESEARCH_DIR, safe_name)
                    with open(target, 'wb') as fh:
                        fh.write(img_bytes)
                    cover_image = f"/static/uploads/research/{safe_name}"
            except Exception:
                pass
        elif 'cover_image' in request.files:
            f = request.files['cover_image']
            if f and f.filename:
                web, _ = save_upload(f, 'research', ALLOWED_IMG)
                if web:
                    cover_image = web

        # إزالة الغلاف؟
        if request.form.get('remove_cover') == '1':
            cover_image = ''

        # PDF: نحتفظ بالقديم افتراضياً
        pdf_file_web = r['pdf_file'] if 'pdf_file' in r.keys() else ''
        # إزالة الـPDF؟
        if request.form.get('remove_pdf') == '1':
            pdf_file_web = ''
        # PDF جديد؟
        if 'pdf_file' in request.files:
            pf = request.files['pdf_file']
            if pf and pf.filename:
                ext = pf.filename.rsplit('.',1)[-1].lower() if '.' in pf.filename else ''
                if ext != 'pdf':
                    flash('ملف البحث يجب أن يكون PDF', 'error')
                    db.close()
                    return redirect(url_for('edit_research', rid=rid))
                if not verify_file_signature(pf, 'pdf'):
                    flash('الملف ليس PDF صالح', 'error')
                    db.close()
                    return redirect(url_for('edit_research', rid=rid))
                safe_name = f"{secrets.token_hex(10)}.pdf"
                target = os.path.join(RESEARCH_DIR, safe_name)
                pf.save(target)
                if os.path.getsize(target) > 50 * 1024 * 1024:
                    os.remove(target)
                    flash('حجم PDF أكبر من 50MB', 'error')
                    db.close()
                    return redirect(url_for('edit_research', rid=rid))
                pdf_file_web = f'/static/uploads/research/{safe_name}'

        db.execute("""UPDATE research SET
                      title=?, summary=?, content=?, tags=?,
                      category_id=?, cover_image=?, pdf_file=?
                      WHERE id=?""",
                   (title, summary, content, tags, cat_id, cover_image, pdf_file_web, rid))

        # صور معرض جديدة (تُضاف للموجودة)
        gallery = request.files.getlist('gallery_images')
        last_sort = db.execute("""SELECT MAX(sort_order) as m FROM research_images
                                  WHERE research_id=?""", (rid,)).fetchone()
        sort = (last_sort['m'] or 0) + 1
        for img_file in gallery[:10]:
            if img_file and img_file.filename:
                web, _ = save_upload(img_file, 'research', ALLOWED_IMG)
                if web:
                    db.execute("""INSERT INTO research_images(research_id,image,sort_order)
                                  VALUES(?,?,?)""", (rid, web, sort))
                    sort += 1

        # حذف صورة من المعرض؟
        remove_ids = request.form.getlist('remove_image')
        for img_id in remove_ids:
            try:
                db.execute("""DELETE FROM research_images
                              WHERE id=? AND research_id=?""", (int(img_id), rid))
            except ValueError:
                pass

        db.commit()
        db.close()
        flash('تم حفظ التعديلات', 'success')
        return redirect(url_for('view_research', rid=rid))

    # GET
    categories = db.execute("SELECT * FROM categories ORDER BY sort_order, id").fetchall()
    gallery = db.execute("""SELECT * FROM research_images WHERE research_id=?
                            ORDER BY sort_order, id""", (rid,)).fetchall()
    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('edit_research.html', user=user, r=r,
                           categories=categories, gallery=gallery,
                           unread_count=unread)


@app.route('/research/<int:rid>/delete', methods=['POST'])
@role_required('admin','owner')
def delete_research(rid):
    user = current_user()

    # تحقق من كلمة المرور (تأكيد للعملية الحساسة)
    confirm_pw = request.form.get('confirm_password', '')
    if not user['password_hash'] or not verify_password(confirm_pw, user['password_hash']):
        flash('❌ يجب تأكيد كلمة المرور لإتمام الحذف', 'error')
        return redirect(url_for('view_research', rid=rid))

    db = get_db()
    r = db.execute("SELECT id,title,user_id FROM research WHERE id=?", (rid,)).fetchone()
    if not r:
        db.close()
        flash('البحث غير موجود', 'error')
        return redirect(url_for('research_list'))

    title = r['title']
    author_id = r['user_id']

    # احذف كل ما يتعلق بالبحث
    db.execute("DELETE FROM bookmarks WHERE research_id=?", (rid,))
    db.execute("DELETE FROM likes WHERE research_id=?", (rid,))
    db.execute("DELETE FROM comments WHERE research_id=?", (rid,))
    db.execute("DELETE FROM research_images WHERE research_id=?", (rid,))
    db.execute("DELETE FROM research WHERE id=?", (rid,))

    # سجل أمني
    security_log(db, user['id'], 'research_deleted',
                 f'research_id={rid}, title={title[:80]}, author_id={author_id}')

    # إشعار للناشر (إن لم يكن هو من حذف)
    if author_id != user['id']:
        notify(db, author_id, f'تم حذف بحثك: {title}', '/profile/' + str(author_id))

    db.commit()
    db.close()
    flash(f'تم حذف البحث "{title}"', 'success')
    return redirect(url_for('research_list'))


# ══════════════════════════════════════
# تثبيت / إلغاء تثبيت بحث في الرئيسية (للمشرفين والمالك)
# الحد الأقصى: 5 أبحاث مثبتة في وقت واحد
# ══════════════════════════════════════
MAX_PINNED = 5

@app.route('/research/<int:rid>/pin', methods=['POST'])
@role_required('admin','owner')
def toggle_pin(rid):
    user = current_user()
    db = get_db()
    r = db.execute("SELECT id, title, is_featured, status FROM research WHERE id=?",
                   (rid,)).fetchone()
    if not r:
        db.close()
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'error':'not_found'}), 404
        flash('البحث غير موجود', 'error')
        return redirect(url_for('research_list'))

    is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest'

    if r['is_featured']:
        # إلغاء التثبيت
        db.execute("UPDATE research SET is_featured=0 WHERE id=?", (rid,))
        db.commit()
        pinned = False
        msg = 'تم إلغاء تثبيت البحث'
    else:
        # لا يمكن تثبيت بحث غير معتمد
        if r['status'] != 'approved':
            db.close()
            if is_ajax:
                return jsonify({'error':'not_approved',
                                'message':'لا يمكن تثبيت بحث غير معتمد'}), 400
            flash('لا يمكن تثبيت بحث غير معتمد', 'error')
            return redirect(url_for('view_research', rid=rid))

        # تحقق من الحد الأقصى
        count = db.execute("SELECT COUNT(*) as c FROM research WHERE is_featured=1").fetchone()['c']
        if count >= MAX_PINNED:
            db.close()
            err_msg = f'وصلت للحد الأقصى ({MAX_PINNED} أبحاث مثبتة). ألغِ تثبيت أحدها أولاً.'
            if is_ajax:
                return jsonify({'error':'max_reached', 'message': err_msg,
                                'max': MAX_PINNED}), 400
            flash(err_msg, 'error')
            return redirect(url_for('view_research', rid=rid))

        db.execute("UPDATE research SET is_featured=1 WHERE id=?", (rid,))
        db.commit()
        pinned = True
        msg = f'تم تثبيت البحث "{r["title"]}" في الرئيسية'

    # العدد الجديد
    new_count = db.execute("SELECT COUNT(*) as c FROM research WHERE is_featured=1").fetchone()['c']
    db.close()

    if is_ajax:
        return jsonify({'pinned': pinned, 'count': new_count, 'max': MAX_PINNED})
    flash(msg, 'success')
    return redirect(url_for('view_research', rid=rid))


# ══════════════════════════════════════
# لوحة المشرفين: مراجعة الأبحاث
# ══════════════════════════════════════
@app.route('/admin/pending')
@role_required('admin','owner')
def pending_research():
    user = current_user()
    db = get_db()
    rows = db.execute("""
        SELECT r.*, u.name as author_name, u.username, u.avatar as author_avatar
        FROM research r JOIN users u ON r.user_id=u.id
        WHERE r.status='pending' ORDER BY r.created_at ASC
    """).fetchall()
    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('pending_research.html', user=user,
                           rows=rows, unread_count=unread)


@app.route('/admin/research/<int:rid>/approve', methods=['POST'])
@role_required('admin','owner')
def approve_research(rid):
    user = current_user()
    db = get_db()
    r = db.execute("SELECT * FROM research WHERE id=?", (rid,)).fetchone()
    if not r:
        db.close(); abort(404)
    db.execute("""UPDATE research SET status='approved', reviewed_by=?, reviewed_at=?
                  WHERE id=?""", (user['id'], datetime.utcnow().isoformat(), rid))
    db.execute("UPDATE users SET points=points+1 WHERE id=?", (r['user_id'],))
    notify(db, r['user_id'], f'تمت الموافقة على بحثك: {r["title"]} (+1 نقطة)',
           f'/research/{rid}')
    # إشعار باقي المستخدمين
    others = db.execute("SELECT id FROM users WHERE id NOT IN (?, ?)",
                        (r['user_id'], user['id'])).fetchall()
    for u in others:
        notify(db, u['id'], f'بحث جديد: {r["title"]}', f'/research/{rid}')
    db.commit()
    db.close()
    flash('تمت الموافقة ونُشر البحث', 'success')
    return redirect(url_for('pending_research'))


@app.route('/admin/research/<int:rid>/reject', methods=['POST'])
@role_required('admin','owner')
def reject_research(rid):
    user = current_user()
    reason = (request.form.get('reason') or '').strip()
    db = get_db()
    r = db.execute("SELECT * FROM research WHERE id=?", (rid,)).fetchone()
    if not r:
        db.close(); abort(404)
    db.execute("""UPDATE research SET status='rejected', reviewed_by=?, reviewed_at=?
                  WHERE id=?""", (user['id'], datetime.utcnow().isoformat(), rid))
    msg = f'تم رفض بحثك: {r["title"]}' + (f' - السبب: {reason}' if reason else '')
    notify(db, r['user_id'], msg, '')
    db.commit()
    db.close()
    flash('تم رفض البحث', 'success')
    return redirect(url_for('pending_research'))


# ══════════════════════════════════════
# إدارة الأقسام (المشرف والمالك)
# ══════════════════════════════════════
@app.route('/admin/categories', methods=['GET','POST'])
@role_required('admin','owner')
def manage_categories():
    user = current_user()
    db = get_db()

    if request.method == 'POST':
        action = request.form.get('action','')

        if action == 'add':
            slug    = (request.form.get('slug') or '').strip().lower()
            name_ar = (request.form.get('name_ar') or '').strip()
            name_en = (request.form.get('name_en') or '').strip()
            icon    = (request.form.get('icon') or 'fa-book').strip()
            color   = (request.form.get('color') or '#7b68ee').strip()

            if not (slug and name_ar and name_en):
                flash('الحقول الإلزامية ناقصة (المعرّف، الاسم العربي، الاسم الإنجليزي)', 'error')
            else:
                # تحقق إن الـslug فريد
                exists = db.execute("SELECT id FROM categories WHERE slug=?", (slug,)).fetchone()
                if exists:
                    flash('هذا المعرّف مستخدم مسبقاً، اختر معرّفاً آخر', 'error')
                else:
                    # احسب أعلى sort_order
                    last = db.execute("SELECT MAX(sort_order) as m FROM categories").fetchone()
                    new_sort = (last['m'] or 0) + 1
                    db.execute("""INSERT INTO categories(slug,name_ar,name_en,icon,color,sort_order)
                                  VALUES(?,?,?,?,?,?)""",
                               (slug, name_ar, name_en, icon, color, new_sort))
                    db.commit()
                    flash(f'تمت إضافة القسم "{name_ar}"', 'success')

        elif action == 'edit':
            cid = request.form.get('cat_id','')
            name_ar = (request.form.get('name_ar') or '').strip()
            name_en = (request.form.get('name_en') or '').strip()
            icon    = (request.form.get('icon') or '').strip()
            color   = (request.form.get('color') or '').strip()

            try:
                cid = int(cid)
            except:
                flash('قسم غير صالح', 'error')
                db.close()
                return redirect(url_for('manage_categories'))

            if not (name_ar and name_en):
                flash('الاسم العربي والإنجليزي مطلوبان', 'error')
            else:
                db.execute("""UPDATE categories
                              SET name_ar=?, name_en=?, icon=?, color=?
                              WHERE id=?""",
                           (name_ar, name_en, icon or 'fa-book', color or '#7b68ee', cid))
                db.commit()
                flash('تم تحديث القسم', 'success')

        elif action == 'delete':
            cid = request.form.get('cat_id','')
            try:
                cid = int(cid)
            except:
                flash('قسم غير صالح', 'error')
                db.close()
                return redirect(url_for('manage_categories'))

            # عدّ الأبحاث في هذا القسم
            count = db.execute("SELECT COUNT(*) as c FROM research WHERE category_id=?",
                               (cid,)).fetchone()['c']
            if count > 0:
                # نخلي الأبحاث الموجودة بلا قسم بدل ما نمنع الحذف
                db.execute("UPDATE research SET category_id=NULL WHERE category_id=?", (cid,))
            db.execute("DELETE FROM categories WHERE id=?", (cid,))
            db.commit()
            flash(f'تم حذف القسم ({count} بحث أصبح بلا قسم)', 'success')

        return redirect(url_for('manage_categories'))

    # GET: اعرض كل الأقسام مع عدد الأبحاث في كل واحد
    cats = db.execute("""
        SELECT c.*, COUNT(r.id) as research_count
        FROM categories c
        LEFT JOIN research r ON r.category_id=c.id AND r.status='approved'
        GROUP BY c.id
        ORDER BY c.sort_order, c.id
    """).fetchall()
    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('manage_categories.html', user=user, categories=cats,
                           unread_count=unread)


# ══════════════════════════════════════
# المالك: إهداء النقاط
# ══════════════════════════════════════
@app.route('/owner/gift-points', methods=['GET','POST'])
@role_required('owner')
def give_points():
    user = current_user()
    db = get_db()

    if request.method == 'POST':
        target_un = (request.form.get('username') or '').strip().lstrip('@')
        try: pts = int(request.form.get('points','0'))
        except: pts = 0
        reason = (request.form.get('reason') or '').strip()

        if not target_un or pts == 0:
            flash('أدخل اسم المستخدم وعدد نقاط صالح', 'error')
            db.close()
            return redirect(url_for('give_points'))

        target = db.execute("SELECT * FROM users WHERE username=?", (target_un,)).fetchone()
        if not target:
            flash('المستخدم غير موجود', 'error')
            db.close()
            return redirect(url_for('give_points'))

        db.execute("UPDATE users SET points=points+? WHERE id=?", (pts, target['id']))
        db.execute("""INSERT INTO points_gifts(from_user,to_user,points,reason)
                      VALUES(?,?,?,?)""",
                   (user['id'], target['id'], pts, reason))
        notify(db, target['id'],
               f'هدية من المالك: {pts:+d} نقطة' + (f' - {reason}' if reason else ''),
               f'/profile/{target["id"]}')
        db.commit()
        flash(f'تم إرسال {pts:+d} نقطة إلى @{target_un}', 'success')

    history = db.execute("""
        SELECT pg.*, u.username as to_username, u.name as to_name
        FROM points_gifts pg JOIN users u ON pg.to_user=u.id
        WHERE pg.from_user=?
        ORDER BY pg.created_at DESC LIMIT 30
    """, (user['id'],)).fetchall()
    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('give_points.html', user=user, history=history,
                           unread_count=unread)


# ══════════════════════════════════════
# الأبحاث المفضلة (Bookmarks)
# ══════════════════════════════════════
@app.route('/research/<int:rid>/bookmark', methods=['POST'])
@login_required
def toggle_bookmark(rid):
    user = current_user()
    # rate limit
    if rate_limit(f'bookmark:{user["id"]}', max_hits=30, window_sec=60):
        return jsonify({'error':'rate_limited'}), 429

    db = get_db()
    # تأكد إن البحث موجود
    r = db.execute("SELECT id FROM research WHERE id=?", (rid,)).fetchone()
    if not r:
        db.close()
        return jsonify({'error':'not_found'}), 404

    existing = db.execute("SELECT id FROM bookmarks WHERE user_id=? AND research_id=?",
                          (user['id'], rid)).fetchone()
    if existing:
        db.execute("DELETE FROM bookmarks WHERE id=?", (existing['id'],))
        bookmarked = False
    else:
        db.execute("INSERT INTO bookmarks(user_id,research_id) VALUES(?,?)",
                   (user['id'], rid))
        bookmarked = True
    db.commit()
    db.close()
    return jsonify({'bookmarked': bookmarked})


@app.route('/bookmarks')
@login_required
def bookmarks_list():
    user = current_user()
    db = get_db()
    rows = db.execute("""
        SELECT r.*, u.name as author_name, u.avatar as author_avatar, u.username,
               c.name_ar as cat_name_ar, c.name_en as cat_name_en,
               c.slug as cat_slug, c.icon as cat_icon, c.color as cat_color,
               b.created_at as bookmarked_at
        FROM bookmarks b
        JOIN research r ON b.research_id=r.id
        JOIN users u ON r.user_id=u.id
        LEFT JOIN categories c ON r.category_id=c.id
        WHERE b.user_id=?
        ORDER BY b.created_at DESC
    """, (user['id'],)).fetchall()
    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('bookmarks.html', user=user, rows=rows, unread_count=unread)


# ══════════════════════════════════════
# متابعة الباحثين
# ══════════════════════════════════════
@app.route('/follow/<int:uid>', methods=['POST'])
@login_required
def toggle_follow(uid):
    user = current_user()
    # rate limit: 20 متابعة-إلغاء/دقيقة (لمنع spam)
    if rate_limit(f'follow:{user["id"]}', max_hits=20, window_sec=60):
        return jsonify({'error':'rate_limited'}), 429

    if uid == user['id']:
        return jsonify({'error':'cannot_follow_self'}), 400

    db = get_db()
    target = db.execute("SELECT id FROM users WHERE id=?", (uid,)).fetchone()
    if not target:
        db.close()
        return jsonify({'error':'not_found'}), 404

    existing = db.execute("SELECT id FROM follows WHERE follower_id=? AND followed_id=?",
                          (user['id'], uid)).fetchone()
    if existing:
        db.execute("DELETE FROM follows WHERE id=?", (existing['id'],))
        following = False
    else:
        db.execute("INSERT INTO follows(follower_id,followed_id) VALUES(?,?)",
                   (user['id'], uid))
        following = True
        # إشعار للمتابَع
        notify(db, uid, f'{user["name"]} بدأ متابعتك', f'/profile/{user["id"]}')
    db.commit()

    # احسب الأعداد الحالية
    followers = db.execute("SELECT COUNT(*) as c FROM follows WHERE followed_id=?",
                           (uid,)).fetchone()['c']
    db.close()
    return jsonify({'following': following, 'followers': followers})


@app.route('/researchers')
@login_required
def researchers_list():
    """قائمة الباحثين (المستخدمين) مع إمكانية المتابعة."""
    user = current_user()
    db = get_db()
    rows = db.execute("""
        SELECT u.id, u.name, u.username, u.avatar, u.bio, u.points, u.role,
               (SELECT COUNT(*) FROM follows WHERE followed_id=u.id) as followers_count,
               (SELECT COUNT(*) FROM research WHERE user_id=u.id AND status='approved') as research_count,
               (SELECT 1 FROM follows WHERE follower_id=? AND followed_id=u.id) as is_following
        FROM users u
        WHERE u.id != ? AND u.is_banned=0
        ORDER BY u.points DESC, research_count DESC
    """, (user['id'], user['id'])).fetchall()
    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('researchers.html', user=user, rows=rows, unread_count=unread)


# ══════════════════════════════════════
# ردود التعليقات
# ══════════════════════════════════════
@app.route('/research/<int:rid>/comment/<int:cid>/reply', methods=['POST'])
@login_required
def reply_comment(rid, cid):
    user = current_user()
    # rate limit: 5 ردود/دقيقة
    if rate_limit(f'reply:{user["id"]}', max_hits=5, window_sec=60):
        flash('أبطئ قليلاً، أرسلت ردوداً كثيرة', 'error')
        return redirect(url_for('view_research', rid=rid))

    content = (request.form.get('content') or '').strip()
    if not content:
        flash('الرد فارغ', 'error')
        return redirect(url_for('view_research', rid=rid))
    if len(content) > 1000:
        content = content[:1000]

    db = get_db()
    # تأكد إن التعليق الأب موجود وفي نفس البحث
    parent = db.execute("SELECT user_id FROM comments WHERE id=? AND research_id=?",
                        (cid, rid)).fetchone()
    if not parent:
        db.close()
        flash('التعليق غير موجود', 'error')
        return redirect(url_for('view_research', rid=rid))

    db.execute("""INSERT INTO comments(research_id,user_id,parent_id,content)
                  VALUES(?,?,?,?)""", (rid, user['id'], cid, content))

    # إشعار لصاحب التعليق الأب (إن لم يكن نفس المعلق)
    if parent['user_id'] != user['id']:
        notify(db, parent['user_id'], f'{user["name"]} رد على تعليقك', f'/research/{rid}')

    db.commit()
    db.close()
    flash('تم نشر الرد', 'success')
    return redirect(url_for('view_research', rid=rid) + f'#c{cid}')


# ══════════════════════════════════════
# لوحة الإحصائيات (للمالك)
# ══════════════════════════════════════
@app.route('/owner/stats')
@role_required('owner')
def owner_stats():
    user = current_user()
    db = get_db()

    # إحصائيات عامة
    total_users    = db.execute("SELECT COUNT(*) as c FROM users").fetchone()['c']
    total_research = db.execute("SELECT COUNT(*) as c FROM research WHERE status='approved'").fetchone()['c']
    pending_count  = db.execute("SELECT COUNT(*) as c FROM research WHERE status='pending'").fetchone()['c']
    total_news     = db.execute("SELECT COUNT(*) as c FROM news").fetchone()['c']
    total_comments = db.execute("SELECT COUNT(*) as c FROM comments").fetchone()['c']
    total_likes    = db.execute("SELECT COUNT(*) as c FROM likes").fetchone()['c']

    # نشاط آخر 7 أيام (أبحاث منشورة لكل يوم)
    weekly = db.execute("""
        SELECT DATE(created_at) as day, COUNT(*) as c
        FROM research WHERE status='approved'
          AND created_at >= datetime('now', '-7 days')
        GROUP BY DATE(created_at)
        ORDER BY day ASC
    """).fetchall()

    # أكثر 5 أبحاث مشاهدةً
    top_research = db.execute("""
        SELECT r.id, r.title, r.views, r.likes, u.name as author
        FROM research r JOIN users u ON r.user_id=u.id
        WHERE r.status='approved'
        ORDER BY r.views DESC LIMIT 5
    """).fetchall()

    # أكثر 5 مستخدمين بنقاط
    top_users = db.execute("""
        SELECT id, name, username, points, role, avatar
        FROM users WHERE is_banned=0
        ORDER BY points DESC LIMIT 5
    """).fetchall()

    # توزيع الأبحاث على الأقسام
    cat_dist = db.execute("""
        SELECT c.name_ar, c.name_en, c.color, c.icon,
               COUNT(r.id) as c_count
        FROM categories c
        LEFT JOIN research r ON r.category_id=c.id AND r.status='approved'
        GROUP BY c.id
        ORDER BY c_count DESC
    """).fetchall()

    # توزيع المستخدمين حسب الدور
    role_dist = db.execute("""
        SELECT role, COUNT(*) as c FROM users
        WHERE is_banned=0
        GROUP BY role
    """).fetchall()

    unread = unread_count_for(db, user['id'])
    db.close()

    return render_template('owner_stats.html', user=user, unread_count=unread,
                           total_users=total_users, total_research=total_research,
                           pending_count=pending_count, total_news=total_news,
                           total_comments=total_comments, total_likes=total_likes,
                           weekly=weekly, top_research=top_research,
                           top_users=top_users, cat_dist=cat_dist,
                           role_dist=role_dist)


# ══════════════════════════════════════
# تغيير رمز المالك (المالك حصراً)
# ══════════════════════════════════════
@app.route('/owner/role-code', methods=['GET','POST'])
@role_required('owner')
def owner_role_code():
    """يسمح للمالك بتغيير رمز التسجيل لدور المالك (وإذا أحب رمز المشرف)."""
    user = current_user()
    db = get_db()

    if request.method == 'POST':
        # rate limit
        if rate_limit(f'rolecode:{user["id"]}', max_hits=5, window_sec=60):
            db.close()
            flash('محاولات كثيرة، انتظر دقيقة', 'error')
            return redirect(url_for('owner_role_code'))

        owner_pw     = request.form.get('owner_password', '')
        new_owner_code = (request.form.get('new_owner_code') or '').strip()
        new_admin_code = (request.form.get('new_admin_code') or '').strip()

        # تأكيد كلمة المرور
        if not verify_password(owner_pw, user['password_hash']):
            security_log(db, user['id'], 'role_code_change_failed', 'wrong password')
            db.commit()
            db.close()
            flash('❌ كلمة المرور غير صحيحة', 'error')
            return redirect(url_for('owner_role_code'))

        # تحقق الرموز
        changed = []
        if new_owner_code:
            if len(new_owner_code) < 6:
                db.close()
                flash('رمز المالك يجب 6 أحرف على الأقل', 'error')
                return redirect(url_for('owner_role_code'))
            set_role_code('owner', new_owner_code, by_user_id=user['id'])
            changed.append('المالك')

        if new_admin_code:
            if len(new_admin_code) < 6:
                db.close()
                flash('رمز المشرف يجب 6 أحرف على الأقل', 'error')
                return redirect(url_for('owner_role_code'))
            set_role_code('admin', new_admin_code, by_user_id=user['id'])
            changed.append('المشرف')

        if not changed:
            db.close()
            flash('لم تُحدد أي رمز جديد', 'error')
            return redirect(url_for('owner_role_code'))

        security_log(db, user['id'], 'role_code_changed',
                     f'changed: {",".join(changed)}')
        db.commit()
        db.close()
        flash(f'✓ تم تحديث رمز {" و ".join(changed)} بنجاح', 'success')
        return redirect(url_for('owner_role_code'))

    current_owner_code = get_role_code('owner')
    current_admin_code = get_role_code('admin')
    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('role_code.html', user=user,
                           current_owner_code=current_owner_code,
                           current_admin_code=current_admin_code,
                           unread_count=unread)


# ══════════════════════════════════════
# توليد الصوت للبحث (TTS)
# ══════════════════════════════════════
@app.route('/research/<int:rid>/audio/generate', methods=['POST'])
@login_required
def research_audio_generate(rid):
    """يولّد ملف صوتي للبحث. يستطيع مؤلف البحث أو مشرف/مالك."""
    user = current_user()
    db = get_db()
    research = db.execute("SELECT * FROM research WHERE id=?", (rid,)).fetchone()
    if not research:
        db.close()
        abort(404)

    # صلاحية: المؤلف أو مشرف/مالك
    is_author = research['user_id'] == user['id']
    if not is_author and user['role'] not in ('admin', 'owner'):
        db.close()
        flash('لا تملك صلاحية لتوليد الصوت لهذا البحث', 'error')
        return redirect(url_for('view_research', rid=rid))

    # rate limit: 3 محاولات/دقيقة
    if rate_limit(f'tts:{user["id"]}', max_hits=3, window_sec=60):
        db.close()
        flash('محاولات كثيرة، انتظر دقيقة', 'error')
        return redirect(url_for('view_research', rid=rid))

    # تأكد إن edge-tts متاحة
    if not EDGE_TTS_AVAILABLE:
        db.close()
        flash('ميزة الصوت غير مفعّلة على السيرفر. على المالك تثبيت: pip install edge-tts', 'error')
        return redirect(url_for('view_research', rid=rid))

    db.close()

    voice_id = (request.form.get('voice') or '').strip()
    if not voice_id or not is_valid_voice(voice_id):
        voice_id = get_default_voice()

    # توليد (synchronous - قد يأخذ 5-30 ثانية)
    success, web_path, err = generate_research_audio(rid, voice_id)

    if success:
        flash('تم توليد الصوت بنجاح ✓', 'success')
    else:
        flash(f'فشل توليد الصوت: {err}', 'error')

    return redirect(url_for('view_research', rid=rid))


@app.route('/owner/tts-settings', methods=['GET', 'POST'])
@role_required('owner')
def owner_tts_settings():
    """إعدادات صوت TTS الافتراضي - للمالك فقط."""
    user = current_user()
    db = get_db()

    if request.method == 'POST':
        new_voice = (request.form.get('default_voice') or '').strip()
        if not is_valid_voice(new_voice):
            db.close()
            flash('صوت غير صالح', 'error')
            return redirect(url_for('owner_tts_settings'))

        db.execute("""INSERT INTO app_settings(key, value, updated_by, updated_at)
                      VALUES('default_tts_voice', ?, ?, CURRENT_TIMESTAMP)
                      ON CONFLICT(key) DO UPDATE
                        SET value=excluded.value,
                            updated_by=excluded.updated_by,
                            updated_at=CURRENT_TIMESTAMP""",
                   (new_voice, user['id']))
        db.commit()
        db.close()
        flash('تم حفظ الصوت الافتراضي ✓', 'success')
        return redirect(url_for('owner_tts_settings'))

    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('tts_settings.html',
                           user=user,
                           voices=ARABIC_VOICES,
                           current_voice=get_default_voice(),
                           tts_available=EDGE_TTS_AVAILABLE,
                           unread_count=unread)


# ══════════════════════════════════════
# السجل الأمني (للمالك فقط)
# ══════════════════════════════════════
@app.route('/owner/security-log')
@role_required('owner')
def view_security_log():
    user = current_user()
    db = get_db()

    # فلتر اختياري
    action_filter = request.args.get('action', '')

    base = """SELECT s.*, u.name as user_name, u.username
              FROM security_log s
              LEFT JOIN users u ON s.user_id = u.id"""
    params = []
    if action_filter:
        base += " WHERE s.action = ?"
        params.append(action_filter)
    base += " ORDER BY s.created_at DESC LIMIT 200"

    logs = db.execute(base, params).fetchall()

    # إحصائيات سريعة
    stats = db.execute("""
        SELECT action, COUNT(*) as c FROM security_log
        WHERE created_at >= datetime('now', '-7 days')
        GROUP BY action ORDER BY c DESC
    """).fetchall()

    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('security_log.html', user=user, logs=logs,
                           stats=stats, action_filter=action_filter,
                           unread_count=unread)


# ══════════════════════════════════════
# تنزيل بحث كـ PDF
# ══════════════════════════════════════
@app.route('/research/<int:rid>/pdf')
@login_required
def research_pdf(rid):
    """ينشئ PDF بسيط من البحث - عبر طباعة HTML من المتصفح.
       حالياً نعيد صفحة HTML مهيأة للطباعة كـPDF."""
    user = current_user()
    db = get_db()
    r = db.execute("""
        SELECT r.*, u.name as author_name, u.username,
               c.name_ar as cat_name_ar, c.name_en as cat_name_en,
               c.color as cat_color
        FROM research r JOIN users u ON r.user_id=u.id
        LEFT JOIN categories c ON r.category_id=c.id
        WHERE r.id=?
    """, (rid,)).fetchone()
    if not r:
        db.close(); return "البحث غير موجود", 404
    if r['status'] != 'approved' and user['id'] != r['user_id'] and user['role'] not in ('admin','owner'):
        db.close(); abort(403)

    gallery = db.execute("""
        SELECT image FROM research_images WHERE research_id=? ORDER BY sort_order
    """, (rid,)).fetchall()

    db.close()
    return render_template('research_pdf.html', r=r, gallery=gallery)


# ══════════════════════════════════════
# البحث العام (شريط الناف بار)
# ══════════════════════════════════════
@app.route('/search')
@login_required
def search():
    """بحث في الأبحاث، الكتب، الصور الفلكية، الباحثين."""
    user = current_user()
    q = (request.args.get('q') or '').strip()
    db = get_db()

    research_results = []
    book_results = []
    astro_results = []
    user_results = []

    if q and len(q) >= 2:
        # نقسّم النص لكلمات مفتاحية، نتجاهل الكلمات القصيرة جداً وحروف الجر
        stop_words = {'في', 'من', 'إلى', 'على', 'عن', 'هذا', 'هذه', 'ذلك', 'تلك',
                      'the', 'a', 'an', 'in', 'on', 'at', 'of', 'to', 'and', 'or'}
        raw_words = q.split()
        keywords = [w.strip() for w in raw_words if len(w.strip()) >= 2 and w.lower() not in stop_words]
        if not keywords:
            keywords = [q]  # احتياط: لو ما لقينا كلمات، نبحث بالنص كله

        # نبني WHERE ديناميكي: كل كلمة OR في كل الحقول
        def build_clause(fields, keywords):
            """يبني (field1 LIKE ? OR field2 LIKE ?...) AND (...) لكل كلمة."""
            clauses = []
            params = []
            for kw in keywords:
                like = f'%{kw}%'
                field_clause = ' OR '.join(f'{f} LIKE ?' for f in fields)
                clauses.append(f'({field_clause})')
                params.extend([like] * len(fields))
            # كل كلمة يجب أن توجد في حقل واحد على الأقل (AND بين الكلمات)
            return ' OR '.join(clauses), params  # OR: أي كلمة تطابق = نتيجة

        # أبحاث
        r_fields = ['r.title','r.summary','r.tags','r.content','u.name','u.username']
        r_clause, r_params = build_clause(r_fields, keywords)
        research_results = db.execute(f"""
            SELECT r.id, r.title, r.summary, r.views, r.likes, r.cover_image,
                   u.name as author_name, u.username as author_username,
                   c.name_ar as cat_name_ar, c.name_en as cat_name_en,
                   c.color as cat_color, c.icon as cat_icon, c.slug as cat_slug
            FROM research r
            JOIN users u ON r.user_id=u.id
            LEFT JOIN categories c ON r.category_id=c.id
            WHERE r.status='approved' AND ({r_clause})
            ORDER BY r.views DESC LIMIT 30
        """, r_params).fetchall()

        # كتب
        b_fields = ['b.title','b.description','b.author_name']
        b_clause, b_params = build_clause(b_fields, keywords)
        book_results = db.execute(f"""
            SELECT b.*, u.name as uploader_name,
                   bc.name_ar as cat_name_ar, bc.color as cat_color, bc.icon as cat_icon
            FROM books b
            JOIN users u ON b.user_id=u.id
            LEFT JOIN book_categories bc ON b.category_id=bc.id
            WHERE {b_clause}
            ORDER BY b.created_at DESC LIMIT 20
        """, b_params).fetchall()

        # صور فلكية
        a_fields = ['a.title','a.description']
        a_clause, a_params = build_clause(a_fields, keywords)
        astro_results = db.execute(f"""
            SELECT a.*, u.name as uploader_name
            FROM astro_images a
            JOIN users u ON a.user_id=u.id
            WHERE {a_clause}
            ORDER BY a.created_at DESC LIMIT 20
        """, a_params).fetchall()

        # باحثون
        u_fields = ['name','username','bio']
        u_clause, u_params = build_clause(u_fields, keywords)
        user_results = db.execute(f"""
            SELECT id, name, username, avatar, bio, points, role,
                   (SELECT COUNT(*) FROM research WHERE user_id=users.id AND status='approved') as rc
            FROM users
            WHERE is_banned=0 AND ({u_clause})
            ORDER BY points DESC LIMIT 10
        """, u_params).fetchall()

    unread = unread_count_for(db, user['id'])
    db.close()

    total = len(research_results) + len(book_results) + len(astro_results) + len(user_results)
    return render_template('search.html', user=user, q=q,
                           research_results=research_results,
                           book_results=book_results,
                           astro_results=astro_results,
                           user_results=user_results,
                           total=total, unread_count=unread)


# ══════════════════════════════════════
# المكتبة (كتب PDF)
# ══════════════════════════════════════
MAX_BOOKS_PER_DAY = 1

@app.route('/library')
@login_required
def library():
    user = current_user()
    db = get_db()
    cat_slug = request.args.get('category', '')

    # أقسام المكتبة
    book_cats = db.execute("""
        SELECT bc.*, COUNT(b.id) as book_count
        FROM book_categories bc
        LEFT JOIN books b ON b.category_id=bc.id
        GROUP BY bc.id
        ORDER BY bc.sort_order, bc.id
    """).fetchall()

    active_cat = None
    if cat_slug:
        active_cat = db.execute("SELECT * FROM book_categories WHERE slug=?",
                                (cat_slug,)).fetchone()

    if active_cat:
        books = db.execute("""
            SELECT b.*, u.name as uploader_name, u.username as uploader_username,
                   bc.name_ar as cat_name_ar, bc.name_en as cat_name_en,
                   bc.color as cat_color, bc.icon as cat_icon, bc.slug as cat_slug
            FROM books b
            JOIN users u ON b.user_id=u.id
            LEFT JOIN book_categories bc ON b.category_id=bc.id
            WHERE b.category_id=?
            ORDER BY b.created_at DESC
        """, (active_cat['id'],)).fetchall()
    else:
        books = db.execute("""
            SELECT b.*, u.name as uploader_name, u.username as uploader_username,
                   bc.name_ar as cat_name_ar, bc.name_en as cat_name_en,
                   bc.color as cat_color, bc.icon as cat_icon, bc.slug as cat_slug
            FROM books b
            JOIN users u ON b.user_id=u.id
            LEFT JOIN book_categories bc ON b.category_id=bc.id
            ORDER BY b.created_at DESC LIMIT 60
        """).fetchall()

    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('library.html', user=user, books=books,
                           book_cats=book_cats, active_cat=active_cat,
                           unread_count=unread)


@app.route('/library/upload', methods=['GET','POST'])
@login_required
def upload_book():
    user = current_user()
    db = get_db()

    # تحقق من الحد اليومي للأعضاء العاديين (المالك/المشرف بدون حد)
    if user['role'] == 'member':
        today_count = db.execute("""
            SELECT COUNT(*) as c FROM books
            WHERE user_id=? AND DATE(created_at)=DATE('now')
        """, (user['id'],)).fetchone()['c']
        if today_count >= MAX_BOOKS_PER_DAY:
            db.close()
            flash(f'وصلت للحد الأقصى اليومي ({MAX_BOOKS_PER_DAY} كتاب/يوم). جرّب غداً.', 'error')
            return redirect(url_for('library'))

    if request.method == 'POST':
        title       = (request.form.get('title') or '').strip()
        description = (request.form.get('description') or '').strip()
        author_name = (request.form.get('author_name') or '').strip()
        cat_id      = request.form.get('category_id', '')

        if not title:
            flash('عنوان الكتاب مطلوب', 'error')
            db.close()
            return redirect(url_for('upload_book'))

        if not cat_id:
            flash('يجب اختيار قسم للكتاب', 'error')
            db.close()
            return redirect(url_for('upload_book'))

        try:
            cat_id = int(cat_id)
            cat_check = db.execute("SELECT id FROM book_categories WHERE id=?",
                                    (cat_id,)).fetchone()
            if not cat_check:
                flash('القسم غير صالح', 'error')
                db.close()
                return redirect(url_for('upload_book'))
        except ValueError:
            flash('قسم غير صالح', 'error')
            db.close()
            return redirect(url_for('upload_book'))

        # ملف الـPDF (مطلوب)
        if 'pdf_file' not in request.files:
            flash('ملف PDF مطلوب', 'error')
            db.close()
            return redirect(url_for('upload_book'))

        pdf_file = request.files['pdf_file']
        if not pdf_file or not pdf_file.filename:
            flash('ملف PDF مطلوب', 'error')
            db.close()
            return redirect(url_for('upload_book'))

        # تحقق من نوع الملف
        filename = pdf_file.filename.lower()
        if not filename.endswith('.pdf'):
            flash('يجب أن يكون الملف بصيغة PDF فقط', 'error')
            db.close()
            return redirect(url_for('upload_book'))

        # فحص magic bytes: تأكد إن المحتوى فعلاً PDF
        if not verify_file_signature(pdf_file, 'pdf'):
            security_log(db, user['id'], 'fake_pdf_upload_blocked',
                         f'filename={pdf_file.filename}')
            db.commit()
            db.close()
            flash('الملف ليس PDF صالحاً (المحتوى لا يطابق الصيغة)', 'error')
            return redirect(url_for('upload_book'))

        # احفظ PDF
        ext = 'pdf'
        safe_name = f"{secrets.token_hex(12)}.{ext}"
        target = os.path.join(BOOKS_DIR, safe_name)
        pdf_file.save(target)
        size = os.path.getsize(target)
        if size > MAX_BOOK_MB * 1024 * 1024:
            os.remove(target)
            flash(f'حجم الملف أكبر من {MAX_BOOK_MB}MB', 'error')
            db.close()
            return redirect(url_for('upload_book'))
        pdf_web = f"/static/uploads/books/{safe_name}"

        # صورة الغلاف (اختياري)
        cover_path = ''
        if 'cover_image' in request.files:
            f = request.files['cover_image']
            if f and f.filename:
                web, _ = save_upload(f, 'books', ALLOWED_IMG)
                if web:
                    cover_path = web

        db.execute("""INSERT INTO books(user_id,category_id,title,description,
                      author_name,cover_image,pdf_file,file_size)
                      VALUES(?,?,?,?,?,?,?,?)""",
                   (user['id'], cat_id, title, description, author_name,
                    cover_path, pdf_web, size))
        db.commit()
        db.close()
        flash('تم رفع الكتاب بنجاح', 'success')
        return redirect(url_for('library'))

    book_cats = db.execute("""SELECT * FROM book_categories
                              ORDER BY sort_order, id""").fetchall()
    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('upload_book.html', user=user,
                           book_cats=book_cats, unread_count=unread,
                           max_mb=MAX_BOOK_MB)


@app.route('/library/<int:bid>/download')
@login_required
def download_book(bid):
    db = get_db()
    book = db.execute("SELECT * FROM books WHERE id=?", (bid,)).fetchone()
    if not book:
        db.close()
        return "الكتاب غير موجود", 404
    db.execute("UPDATE books SET downloads=downloads+1 WHERE id=?", (bid,))
    db.commit()
    pdf = book['pdf_file']
    db.close()
    return redirect(pdf)


@app.route('/library/<int:bid>/delete', methods=['POST'])
@role_required('admin','owner')
def delete_book(bid):
    user = current_user()

    # تأكيد كلمة المرور
    confirm_pw = request.form.get('confirm_password', '')
    if not user['password_hash'] or not verify_password(confirm_pw, user['password_hash']):
        flash('❌ يجب تأكيد كلمة المرور لإتمام الحذف', 'error')
        return redirect(url_for('library'))

    db = get_db()
    book = db.execute("SELECT * FROM books WHERE id=?", (bid,)).fetchone()
    if not book:
        db.close()
        flash('الكتاب غير موجود', 'error')
        return redirect(url_for('library'))

    # حذف الملف الفعلي
    try:
        path = book['pdf_file'].lstrip('/')
        full = os.path.join(app.root_path, path)
        if os.path.exists(full):
            os.remove(full)
    except Exception:
        pass

    # سجل أمني
    security_log(db, user['id'], 'book_deleted',
                 f'book_id={bid}, title={book["title"][:80]}')

    db.execute("DELETE FROM books WHERE id=?", (bid,))
    db.commit()
    db.close()
    flash('تم حذف الكتاب', 'success')
    return redirect(url_for('library'))


# إدارة أقسام المكتبة
@app.route('/library/categories', methods=['GET','POST'])
@role_required('admin','owner')
def manage_book_categories():
    user = current_user()
    db = get_db()

    if request.method == 'POST':
        action = request.form.get('action','')
        if action == 'add':
            slug    = (request.form.get('slug') or '').strip().lower()
            name_ar = (request.form.get('name_ar') or '').strip()
            name_en = (request.form.get('name_en') or '').strip()
            icon    = (request.form.get('icon') or 'fa-book').strip()
            color   = (request.form.get('color') or '#7b68ee').strip()
            if not (slug and name_ar and name_en):
                flash('كل الحقول مطلوبة', 'error')
            else:
                exists = db.execute("SELECT id FROM book_categories WHERE slug=?",
                                     (slug,)).fetchone()
                if exists:
                    flash('المعرّف مستخدم', 'error')
                else:
                    last = db.execute("SELECT MAX(sort_order) as m FROM book_categories").fetchone()
                    new_sort = (last['m'] or 0) + 1
                    db.execute("""INSERT INTO book_categories(slug,name_ar,name_en,icon,color,sort_order)
                                  VALUES(?,?,?,?,?,?)""",
                               (slug, name_ar, name_en, icon, color, new_sort))
                    db.commit()
                    flash('تم إضافة القسم', 'success')
        elif action == 'delete':
            cid = request.form.get('cat_id','')
            try:
                cid = int(cid)
                db.execute("UPDATE books SET category_id=NULL WHERE category_id=?", (cid,))
                db.execute("DELETE FROM book_categories WHERE id=?", (cid,))
                db.commit()
                flash('تم حذف القسم', 'success')
            except ValueError:
                flash('قسم غير صالح', 'error')
        return redirect(url_for('manage_book_categories'))

    cats = db.execute("""
        SELECT bc.*, COUNT(b.id) as book_count
        FROM book_categories bc
        LEFT JOIN books b ON b.category_id=bc.id
        GROUP BY bc.id
        ORDER BY bc.sort_order, bc.id
    """).fetchall()
    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('manage_book_categories.html', user=user,
                           categories=cats, unread_count=unread)


# ══════════════════════════════════════
# الصور الفلكية
# ══════════════════════════════════════
@app.route('/astro')
@login_required
def astro_gallery():
    user = current_user()
    db = get_db()
    images = db.execute("""
        SELECT a.*, u.name as uploader_name, u.username as uploader_username,
               u.avatar as uploader_avatar
        FROM astro_images a
        JOIN users u ON a.user_id=u.id
        ORDER BY a.created_at DESC LIMIT 60
    """).fetchall()
    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('astro.html', user=user, images=images, unread_count=unread)


@app.route('/astro/upload', methods=['GET','POST'])
@login_required
def upload_astro():
    user = current_user()
    db = get_db()

    if request.method == 'POST':
        title       = (request.form.get('title') or '').strip()
        description = (request.form.get('description') or '').strip()

        if not title:
            flash('عنوان الصورة مطلوب', 'error')
            db.close()
            return redirect(url_for('upload_astro'))

        if 'image' not in request.files:
            flash('الصورة مطلوبة', 'error')
            db.close()
            return redirect(url_for('upload_astro'))

        img = request.files['image']
        if not img or not img.filename:
            flash('الصورة مطلوبة', 'error')
            db.close()
            return redirect(url_for('upload_astro'))

        # تحقق من الصيغة
        fn_lower = img.filename.lower()
        ext_ok = any(fn_lower.endswith('.' + e) for e in ALLOWED_IMG)
        if not ext_ok:
            flash('صيغة الصورة غير مدعومة', 'error')
            db.close()
            return redirect(url_for('upload_astro'))

        # فحص magic bytes
        ext = fn_lower.rsplit('.', 1)[-1]
        if not verify_file_signature(img, ext):
            security_log(db, user['id'], 'fake_image_upload_blocked',
                         f'filename={img.filename}, claimed_ext={ext}')
            db.commit()
            db.close()
            flash('الصورة ليست صالحة (المحتوى لا يطابق الصيغة)', 'error')
            return redirect(url_for('upload_astro'))

        # احفظ مباشرة (بدون حد معين كما طلب المستخدم - لكن نضع MAX_ASTRO_MB كحد قصوى عملي)
        safe_name = f"{secrets.token_hex(12)}.{ext}"
        target = os.path.join(ASTRO_DIR, safe_name)
        img.save(target)
        size = os.path.getsize(target)
        if size > MAX_ASTRO_MB * 1024 * 1024:
            os.remove(target)
            flash(f'الصورة أكبر من الحد المسموح ({MAX_ASTRO_MB}MB)', 'error')
            db.close()
            return redirect(url_for('upload_astro'))

        web_path = f"/static/uploads/astro/{safe_name}"
        db.execute("""INSERT INTO astro_images(user_id,title,description,image,file_size)
                      VALUES(?,?,?,?,?)""",
                   (user['id'], title, description, web_path, size))
        db.commit()
        db.close()
        flash('تم رفع الصورة بنجاح', 'success')
        return redirect(url_for('astro_gallery'))

    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('upload_astro.html', user=user, unread_count=unread,
                           max_mb=MAX_ASTRO_MB)


@app.route('/astro/<int:aid>')
@login_required
def view_astro(aid):
    user = current_user()
    db = get_db()
    img = db.execute("""
        SELECT a.*, u.name as uploader_name, u.username as uploader_username,
               u.avatar as uploader_avatar
        FROM astro_images a JOIN users u ON a.user_id=u.id
        WHERE a.id=?
    """, (aid,)).fetchone()
    if not img:
        db.close()
        return "الصورة غير موجودة", 404
    db.execute("UPDATE astro_images SET views=views+1 WHERE id=?", (aid,))
    db.commit()
    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('view_astro.html', user=user, img=img, unread_count=unread)


@app.route('/astro/<int:aid>/delete', methods=['POST'])
@login_required
def delete_astro(aid):
    user = current_user()
    db = get_db()
    img = db.execute("SELECT * FROM astro_images WHERE id=?", (aid,)).fetchone()
    if not img:
        db.close()
        return redirect(url_for('astro_gallery'))
    # المالك/المشرف أو صاحب الصورة
    if user['role'] not in ('admin','owner') and img['user_id'] != user['id']:
        db.close()
        abort(403)

    try:
        path = img['image'].lstrip('/')
        full = os.path.join(app.root_path, path)
        if os.path.exists(full):
            os.remove(full)
    except Exception:
        pass

    db.execute("DELETE FROM astro_images WHERE id=?", (aid,))
    db.commit()
    db.close()
    flash('تم حذف الصورة', 'success')
    return redirect(url_for('astro_gallery'))


# ══════════════════════════════════════
# الرسائل العامة (Broadcasts من المالك/المشرف لكل الأعضاء)
# ══════════════════════════════════════
@app.route('/admin/broadcast', methods=['GET','POST'])
@role_required('admin','owner')
def broadcast():
    user = current_user()
    db = get_db()

    if request.method == 'POST':
        title   = (request.form.get('title') or '').strip()
        content = (request.form.get('content') or '').strip()
        confirm_pw = request.form.get('confirm_password', '')

        if not (title and content):
            flash('العنوان والمحتوى مطلوبان', 'error')
            db.close()
            return redirect(url_for('broadcast'))

        # تأكيد كلمة المرور (عملية حساسة - تصل لكل المستخدمين)
        if not user['password_hash'] or not verify_password(confirm_pw, user['password_hash']):
            db.close()
            flash('❌ يجب تأكيد كلمة المرور لإرسال الرسالة العامة', 'error')
            return redirect(url_for('broadcast'))

        if len(title) > 200:
            title = title[:200]
        if len(content) > 2000:
            content = content[:2000]

        # سجل في جدول broadcasts
        recipients = db.execute("""SELECT id FROM users
                                   WHERE id != ? AND is_banned=0""",
                                (user['id'],)).fetchall()
        db.execute("""INSERT INTO broadcasts(sender_id,title,content,recipients)
                      VALUES(?,?,?,?)""",
                   (user['id'], title, content, len(recipients)))

        # أرسل إشعار لكل مستخدم
        for r in recipients:
            db.execute("""INSERT INTO notifications(user_id,message,link)
                          VALUES(?,?,?)""",
                       (r['id'], f'📢 رسالة عامة: {title}', '/notifications'))

        # سجل أمني
        security_log(db, user['id'], 'broadcast_sent',
                     f'title={title[:80]}, recipients={len(recipients)}')

        db.commit()
        db.close()
        flash(f'تم إرسال الرسالة إلى {len(recipients)} مستخدم', 'success')
        return redirect(url_for('broadcast'))

    # سجل آخر الرسائل المُرسلة
    history = db.execute("""
        SELECT b.*, u.name as sender_name
        FROM broadcasts b JOIN users u ON b.sender_id=u.id
        ORDER BY b.created_at DESC LIMIT 20
    """).fetchall()
    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('broadcast.html', user=user, history=history,
                           unread_count=unread)


# ══════════════════════════════════════
# الأخبار
# ══════════════════════════════════════
@app.route('/news')
@login_required
def news_list():
    user = current_user()
    db = get_db()
    rows = db.execute("""
        SELECT n.*, u.name as author_name, u.avatar as author_avatar, u.username
        FROM news n JOIN users u ON n.user_id=u.id
        ORDER BY n.created_at DESC
    """).fetchall()
    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('news.html', user=user, rows=rows, unread_count=unread)


@app.route('/news/<int:nid>')
@login_required
def view_news(nid):
    user = current_user()
    db = get_db()
    r = db.execute("""
        SELECT n.*, u.name as author_name, u.avatar as author_avatar, u.username
        FROM news n JOIN users u ON n.user_id=u.id WHERE n.id=?
    """, (nid,)).fetchone()
    if not r:
        db.close(); return "الخبر غير موجود", 404
    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('view_news.html', user=user, r=r, unread_count=unread)


@app.route('/news/new', methods=['GET','POST'])
@role_required('admin','owner')
def new_news():
    user = current_user()
    db = get_db()

    if request.method == 'POST':
        title   = (request.form.get('title') or '').strip()
        content = (request.form.get('content') or '').strip()

        if not (title and content):
            flash('العنوان والمحتوى مطلوبان', 'error')
            db.close()
            return redirect(url_for('new_news'))

        # صورة الخبر (اختيارية لكن مستحبة) - الأولوية لـcropper
        image = ''
        image_cropped = (request.form.get('image_cropped') or '').strip()
        if image_cropped and image_cropped.startswith('data:image/'):
            try:
                import base64
                header, b64data = image_cropped.split(',', 1)
                if 'jpeg' in header or 'jpg' in header: ext = 'jpg'
                elif 'png' in header: ext = 'png'
                elif 'webp' in header: ext = 'webp'
                else: ext = 'jpg'
                img_bytes = base64.b64decode(b64data)
                if len(img_bytes) <= MAX_UPLOAD_MB * 1024 * 1024:
                    safe_name = f"news_{secrets.token_hex(10)}.{ext}"
                    target = os.path.join(NEWS_DIR, safe_name)
                    with open(target, 'wb') as fh:
                        fh.write(img_bytes)
                    image = f"/static/uploads/news/{safe_name}"
            except Exception:
                pass
        elif 'image' in request.files:
            f = request.files['image']
            if f and f.filename:
                web, _ = save_upload(f, 'news', ALLOWED_IMG)
                if web:
                    image = web
                else:
                    flash('صيغة الصورة غير مدعومة', 'error')

        db.execute("""INSERT INTO news(user_id,title,content,image) VALUES(?,?,?,?)""",
                   (user['id'], title, content, image))
        nid = db.execute("SELECT last_insert_rowid()").fetchone()[0]

        # إشعار لكل المستخدمين
        others = db.execute("SELECT id FROM users WHERE id!=?", (user['id'],)).fetchall()
        for u in others:
            notify(db, u['id'], f'خبر جديد: {title}', f'/news/{nid}')
        db.commit()
        db.close()
        flash('تم نشر الخبر', 'success')
        return redirect(url_for('news_list'))

    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('new_news.html', user=user, unread_count=unread)


@app.route('/news/<int:nid>/edit', methods=['GET','POST'])
@role_required('admin','owner')
def edit_news(nid):
    user = current_user()
    db = get_db()
    n = db.execute("SELECT * FROM news WHERE id=?", (nid,)).fetchone()
    if not n:
        db.close()
        return "الخبر غير موجود", 404

    if request.method == 'POST':
        title   = request.form.get('title','').strip()
        content = request.form.get('content','').strip()
        if not (title and content):
            flash('العنوان والمحتوى مطلوبان', 'error')
            db.close()
            return redirect(url_for('edit_news', nid=nid))

        image = n['image']  # نُبقي القديمة افتراضياً
        image_cropped = (request.form.get('image_cropped') or '').strip()
        if image_cropped and image_cropped.startswith('data:image/'):
            try:
                import base64
                header, b64data = image_cropped.split(',', 1)
                if 'jpeg' in header or 'jpg' in header: ext = 'jpg'
                elif 'png' in header: ext = 'png'
                elif 'webp' in header: ext = 'webp'
                else: ext = 'jpg'
                img_bytes = base64.b64decode(b64data)
                if len(img_bytes) <= MAX_UPLOAD_MB * 1024 * 1024:
                    safe_name = f"news_{secrets.token_hex(10)}.{ext}"
                    target = os.path.join(NEWS_DIR, safe_name)
                    with open(target, 'wb') as fh:
                        fh.write(img_bytes)
                    image = f"/static/uploads/news/{safe_name}"
            except Exception:
                pass
        elif 'image' in request.files:
            f = request.files['image']
            if f and f.filename:
                web, _ = save_upload(f, 'news', ALLOWED_IMG)
                if web:
                    image = web

        # إزالة الصورة؟
        if request.form.get('remove_image') == '1':
            image = ''

        db.execute("UPDATE news SET title=?, content=?, image=? WHERE id=?",
                   (title, content, image, nid))
        db.commit()
        db.close()
        flash('تم حفظ التعديلات', 'success')
        return redirect(url_for('view_news', nid=nid))

    unread = unread_count_for(db, user['id'])
    db.close()
    return render_template('edit_news.html', user=user, n=n, unread_count=unread)


@app.route('/news/<int:nid>/delete', methods=['POST'])
@role_required('admin','owner')
def delete_news(nid):
    db = get_db()
    db.execute("DELETE FROM news WHERE id=?", (nid,))
    db.commit(); db.close()
    flash('تم حذف الخبر', 'success')
    return redirect(url_for('news_list'))


# ══════════════════════════════════════
# الإشعارات
# ══════════════════════════════════════
@app.route('/notifications')
@login_required
def notifications():
    user = current_user()
    db = get_db()
    notifs = db.execute("""
        SELECT * FROM notifications WHERE user_id=?
        ORDER BY created_at DESC LIMIT 50
    """, (user['id'],)).fetchall()
    db.execute("UPDATE notifications SET is_read=1 WHERE user_id=?", (user['id'],))
    db.commit()
    db.close()
    return render_template('notifications.html', user=user, notifs=notifs, unread_count=0)


@app.route('/api/notifications/count')
@login_required
def notif_count():
    user = current_user()
    db = get_db()
    cnt = unread_count_for(db, user['id'])
    db.close()
    return jsonify({'count': cnt})


# ══════════════════════════════════════
# API عام
# ══════════════════════════════════════
@app.route('/api/users')
@login_required
def api_users():
    db = get_db()
    rows = db.execute("SELECT id,name,username,avatar,points FROM users").fetchall()
    db.close()
    return jsonify([dict(r) for r in rows])


# ══════════════════════════════════════
# تشغيل التطبيق
# ══════════════════════════════════════
if __name__ == '__main__':
    init_db()
    print("=" * 50)
    print("  المرصد العلمي  -  Scientific Observatory")
    print("=" * 50)
    print(f"  Google OAuth: {'مفعّل' if GOOGLE_ENABLED else 'غير مفعّل (وضع تجريبي)'}")
    print(f"  الرموز: member={ROLE_CODES['member']!r}")
    print(f"          admin={ROLE_CODES['admin']!r}")
    print(f"          owner={ROLE_CODES['owner']!r}")
    print(f"  http://localhost:5000")
    print("=" * 50)
    app.run(debug=True, port=5000, host='0.0.0.0')
