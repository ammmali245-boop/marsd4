// service worker بسيط: cache-first للملفات الستاتيكية، network-first للديناميكي
const CACHE = 'marsad-v1';
const STATIC = [
  '/static/img/logo.jpg',
  '/static/img/default_avatar.png',
  '/static/manifest.json',
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE).then(c => c.addAll(STATIC).catch(() => null))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // ستاتيك: cache-first
  if (url.pathname.startsWith('/static/')) {
    e.respondWith(
      caches.match(req).then(hit => hit || fetch(req).then(resp => {
        const copy = resp.clone();
        caches.open(CACHE).then(c => c.put(req, copy));
        return resp;
      }).catch(() => caches.match('/static/img/logo.jpg')))
    );
    return;
  }

  // الباقي: network-first مع fallback للكاش
  e.respondWith(
    fetch(req).catch(() => caches.match(req))
  );
});
