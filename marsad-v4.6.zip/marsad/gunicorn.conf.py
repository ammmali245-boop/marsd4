# إعدادات Gunicorn للإنتاج
import multiprocessing

# المنفذ الذي يستمع عليه Gunicorn (localhost فقط - Nginx يمرر له)
bind = "127.0.0.1:8000"

# عدد العمليات (workers)
# القاعدة: (2 × CPU cores) + 1
# لـKVM 1 (1 CPU): 3 workers مناسب لـ1000 مستخدم
workers = 3

# نوع worker - sync بسيط ويعمل جيداً مع Flask
worker_class = "sync"

# الحد الأقصى للطلبات قبل إعادة تشغيل worker (لمنع تسريب الذاكرة)
max_requests = 1000
max_requests_jitter = 50

# مهلة الطلب (للأبحاث الطويلة + توليد الصوت)
timeout = 300

# حافظ على الاتصالات
keepalive = 5

# السجلات
accesslog = "/var/log/marsad/access.log"
errorlog = "/var/log/marsad/error.log"
loglevel = "info"

# مستخدم وعملية
# user = "www-data"
# group = "www-data"

# تطبيق
wsgi_app = "app:app"
