#!/bin/bash
# ════════════════════════════════════════════════════════
#  سكريبت تثبيت المرصد العلمي على Hostinger VPS Ubuntu 24.04
#  استخدام: bash setup.sh
# ════════════════════════════════════════════════════════

set -e  # توقف عند أي خطأ

echo "════════════════════════════════════════"
echo " بدء تثبيت المرصد العلمي"
echo "════════════════════════════════════════"

cd /var/www/marsad

# 1. إنشاء البيئة الافتراضية لـPython
echo ""
echo "▶ 1/8 إنشاء بيئة Python الافتراضية..."
python3 -m venv venv
source venv/bin/activate

# 2. ترقية pip
echo ""
echo "▶ 2/8 ترقية pip..."
pip install --upgrade pip

# 3. تثبيت المتطلبات
echo ""
echo "▶ 3/8 تثبيت متطلبات Python..."
pip install -r requirements.txt

# 4. إنشاء ملف .env
echo ""
echo "▶ 4/8 إنشاء ملف .env..."
if [ ! -f .env ]; then
    # توليد مفاتيح آمنة
    SECRET=$(python3 -c "import secrets; print(secrets.token_hex(32))")
    OWNER_CODE=$(python3 -c "import secrets; print(secrets.token_urlsafe(16))")
    ADMIN_CODE=$(python3 -c "import secrets; print(secrets.token_urlsafe(16))")

    cat > .env << EOF
SECRET_KEY=$SECRET
OWNER_CODE=$OWNER_CODE
ADMIN_CODE=$ADMIN_CODE
SESSION_COOKIE_SECURE=False
EOF
    echo "  ✓ تم إنشاء .env بمفاتيح عشوائية"
    echo "  ⚠ احفظ هذه الرموز:"
    echo "     OWNER_CODE: $OWNER_CODE"
    echo "     ADMIN_CODE: $ADMIN_CODE"
fi

# 5. إنشاء مجلدات السجلات والرفع
echo ""
echo "▶ 5/8 إنشاء المجلدات..."
mkdir -p /var/log/marsad
mkdir -p static/uploads/{avatars,research,news,books,astro,audio}

# 6. تثبيت خدمة systemd
echo ""
echo "▶ 6/8 تثبيت خدمة Gunicorn..."
cp marsad.service /etc/systemd/system/marsad.service
systemctl daemon-reload
systemctl enable marsad
systemctl start marsad

# 7. تثبيت Nginx config
echo ""
echo "▶ 7/8 إعداد Nginx..."
cp nginx-marsad.conf /etc/nginx/sites-available/marsad
ln -sf /etc/nginx/sites-available/marsad /etc/nginx/sites-enabled/marsad
rm -f /etc/nginx/sites-enabled/default
nginx -t
systemctl restart nginx

# 8. تفعيل الجدار الناري
echo ""
echo "▶ 8/8 تفعيل الجدار الناري..."
ufw allow OpenSSH
ufw allow 'Nginx Full'
ufw --force enable

echo ""
echo "════════════════════════════════════════"
echo " ✅ التثبيت اكتمل بنجاح!"
echo "════════════════════════════════════════"
echo ""
echo "موقعك متاح الآن على:"
echo "  http://$(curl -s ifconfig.me)"
echo ""
echo "للتحقق من حالة الخدمة:"
echo "  systemctl status marsad"
echo ""
echo "لرؤية السجلات:"
echo "  journalctl -u marsad -f"
echo ""
echo "═══════════════════════════════════════════"
echo " معلومات الدخول للمالك والمشرف:"
echo "═══════════════════════════════════════════"
grep -E "OWNER_CODE|ADMIN_CODE" .env
echo "═══════════════════════════════════════════"
