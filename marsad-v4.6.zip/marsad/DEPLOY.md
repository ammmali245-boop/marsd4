# دليل نشر المرصد العلمي على Hostinger VPS

## المتطلبات
- VPS مع Ubuntu 24.04 (Hostinger KVM 1 يكفي)
- اتصال SSH (Termius أو Browser Terminal)
- حساب GitHub (لرفع الكود)

---

## الخطوات

### 1. ارفع الكود على GitHub
- أنشئ Repository (Public أو Private)
- ارفع كل ملفات المشروع

### 2. اتصل بالسيرفر عبر SSH
استخدم Browser Terminal من Hostinger، أو Termius.

### 3. حمّل المشروع
```bash
cd /var/www
git clone https://github.com/USERNAME/REPO.git marsad
cd marsad
```

(لو كان Repository خاص، أضف Token: `https://TOKEN@github.com/USERNAME/REPO.git`)

### 4. شغّل سكريبت التثبيت
```bash
bash setup.sh
```

السكريبت سيقوم بـ:
- تثبيت Python و Nginx
- إنشاء بيئة افتراضية
- توليد مفاتيح أمان عشوائية
- إعداد Gunicorn كخدمة دائمة
- إعداد Nginx كـreverse proxy
- تفعيل الجدار الناري

سيستغرق 5-10 دقائق.

### 5. احفظ رموز الدخول
في نهاية السكريبت، ستظهر رموز OWNER_CODE و ADMIN_CODE.
**احفظها في مكان آمن!**

### 6. افتح الموقع
http://YOUR_SERVER_IP

---

## أوامر مفيدة

### التحقق من الحالة
```bash
systemctl status marsad
systemctl status nginx
```

### إعادة تشغيل
```bash
systemctl restart marsad   # بعد تعديل app.py
systemctl reload nginx     # بعد تعديل nginx config
```

### رؤية السجلات
```bash
journalctl -u marsad -f    # سجلات حية
tail -f /var/log/marsad/error.log
tail -f /var/log/nginx/marsad-error.log
```

### تحديث الكود (لما تعدّل على GitHub)
```bash
cd /var/www/marsad
git pull
systemctl restart marsad
```

---

## إضافة اسم نطاق (.com)

### 1. اشترِ النطاق
من Hostinger أو Namecheap (~$10/سنة).

### 2. وجّه DNS للسيرفر
في إعدادات النطاق:
- نوع: A
- اسم: @
- قيمة: 46.202.188.240 (IP السيرفر)
- TTL: 3600

### 3. عدّل Nginx config
```bash
nano /etc/nginx/sites-available/marsad
```

غيّر `server_name _;` إلى:
```
server_name domain.com www.domain.com;
```

### 4. أعد تشغيل Nginx
```bash
systemctl reload nginx
```

### 5. أضف SSL (https)
```bash
apt install certbot python3-certbot-nginx -y
certbot --nginx -d domain.com -d www.domain.com
```

اتبع التعليمات، وستحصل على https مجاناً.

---

## مشاكل شائعة

### الموقع لا يفتح
```bash
systemctl status marsad nginx
# لو في خطأ، شاهد السجلات:
journalctl -u marsad -n 50
```

### خطأ "Bad Gateway"
يعني Gunicorn متوقف. شغله:
```bash
systemctl restart marsad
```

### رفع الملفات فشل
الحجم الأقصى في Nginx 250MB. لو احتجت أكثر، عدّل `client_max_body_size`.

### الصوت لا يعمل
edge-tts يحتاج اتصال خارجي بـMicrosoft. لو الجدار الناري يحظره:
```bash
ufw allow out 443/tcp
```

---

## النسخ الاحتياطي

### يدوي
```bash
cd /var/www
tar -czvf marsad-backup-$(date +%F).tar.gz marsad/marsad.db marsad/static/uploads/
```

### تلقائي يومياً
أضف في crontab:
```bash
crontab -e
```

اكتب:
```
0 3 * * * cd /var/www && tar -czf /backup/marsad-$(date +\%F).tar.gz marsad/marsad.db marsad/static/uploads/
```

---

## أمان أساسي

### غيّر كلمة مرور root
```bash
passwd
```

### حدّث النظام دورياً
```bash
apt update && apt upgrade -y
```

### تابع المحاولات الفاشلة
```bash
fail2ban-client status
```
